"""
Configuration management for the arbitrage bot.
"""

import json
import logging
import os
import sys

from dotenv import load_dotenv

logger = logging.getLogger(__name__)

load_dotenv()


def _detect_portable_mode() -> bool:
    """Detect if running in portable mode by checking for portable.flag."""
    # Check if portable.flag exists in the same directory as main.py or executable
    if getattr(sys, "frozen", False):
        # Running as compiled executable
        app_dir = os.path.dirname(sys.executable)
    else:
        # Running as script
        app_dir = os.path.dirname(os.path.abspath(__file__))
        # Go up to project root
        app_dir = os.path.dirname(os.path.dirname(app_dir))

    portable_flag = os.path.join(app_dir, "portable.flag")
    return os.path.exists(portable_flag)


def _get_config_dir() -> str:
    """Get configuration directory, using portable_data/ if in portable mode."""
    if _detect_portable_mode():
        # Running in portable mode - use portable_data/ directory
        if getattr(sys, "frozen", False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

        config_dir = os.path.join(base_dir, "portable_data", "config")
        os.makedirs(config_dir, exist_ok=True)
        return config_dir
    else:
        # Normal mode - use config/ directory
        return "config"


# Configuration file path (detects portable mode)
CONFIG_DIR = _get_config_dir()
CONFIG_FILE = os.path.join(CONFIG_DIR, "bot_config.json")
BOOKMAKERS_FILE = os.path.join(CONFIG_DIR, "bookmakers.json")


class Config:
    """Configuration settings for the arbitrage bot."""

    # API Configuration - Paid APIs removed, only free providers available
    # Legacy single API removed - use multi-API orchestrator with SofaScore Scraper

    # Test Mode
    TEST_MODE: bool = os.getenv("TEST_MODE", "0") == "1"

    # Legacy API Key (for backward compatibility with setup wizard)
    ODDS_API_KEY: str = os.getenv("ODDS_API_KEY", "") or ""

    # Multi-API Configuration
    USE_MULTI_API: bool = os.getenv("USE_MULTI_API", "false").lower() == "true"

    # Bot Configuration
    MIN_PROFIT_PERCENTAGE: float = float(os.getenv("MIN_PROFIT_PERCENTAGE", "1.0"))
    MAX_STAKE: float = float(os.getenv("MAX_STAKE", "1000.0"))
    DEFAULT_STAKE: float = float(os.getenv("DEFAULT_STAKE", "100.0"))

    # Alert Configuration
    # Disable sound alerts by default to prevent disruptive notification sounds.
    # Can be re-enabled by setting ENABLE_SOUND_ALERTS=true in the environment.
    ENABLE_SOUND_ALERTS: bool = os.getenv("ENABLE_SOUND_ALERTS", "false").lower() == "true"
    PROFIT_THRESHOLD_ALERT: float = float(os.getenv("PROFIT_THRESHOLD_ALERT", "5.0"))

    # Anti-Detection Settings
    ROUND_STAKES: bool = os.getenv("ROUND_STAKES", "true").lower() == "true"
    VARY_BET_SIZES: bool = os.getenv("VARY_BET_SIZES", "true").lower() == "true"
    MAX_BET_VARIATION_PERCENT: float = float(os.getenv("MAX_BET_VARIATION_PERCENT", "5.0"))
    MIN_STAKE_THRESHOLD: float = float(os.getenv("MIN_STAKE_THRESHOLD", "10.0"))
    BET_DELAY_SECONDS: int = int(os.getenv("BET_DELAY_SECONDS", "15"))

    # Update Interval (seconds)
    UPDATE_INTERVAL: int = int(os.getenv("UPDATE_INTERVAL", "30"))

    # Risk Management
    MAX_MARKET_AGE_HOURS: float = float(os.getenv("MAX_MARKET_AGE_HOURS", "24.0"))
    CRITICAL_STEALTH_THRESHOLD: float = float(os.getenv("CRITICAL_STEALTH_THRESHOLD", "0.2"))

    # Opportunity count enforcement
    # Ensure the UI always shows at least N arbitrage opportunities at startup and on every refresh.
    MIN_STARTUP_OPPORTUNITIES: int = int(os.getenv("MIN_STARTUP_OPPORTUNITIES", "50"))
    MIN_REFRESH_OPPORTUNITIES: int = int(os.getenv("MIN_REFRESH_OPPORTUNITIES", "50"))
    # Synthetic opportunities are DISABLED by default. Can be overridden by env or config file.
    SYNTHESIZE_OPPORTUNITIES_WHEN_LOW: bool = (
        os.getenv("SYNTHESIZE_OPPORTUNITIES_WHEN_LOW", "false").strip().lower() in {"1", "true", "yes"}
    )
    SYNTHETIC_MAX_PROFIT_PERCENTAGE: float = float(os.getenv("SYNTHETIC_MAX_PROFIT_PERCENTAGE", "5.0"))

    # Data Integrity Policy
    # Enforce real data only across the project. When enabled, any synthetic/top-up
    # generation paths must be disabled, regardless of per-feature toggles.
    # Default is enabled to comply with "no mock/placeholder/synthetic data" policy.
    REAL_DATA_ONLY: bool = (
        os.getenv("REAL_DATA_ONLY", "true").strip().lower() in {"1", "true", "yes"}
    )

    # Live Arbitrage Configuration
    ENABLE_LIVE_ARBITRAGE: bool = os.getenv("ENABLE_LIVE_ARBITRAGE", "false").lower() == "true"
    LIVE_ARBITRAGE_SPORT: str = os.getenv("LIVE_ARBITRAGE_SPORT", "baseball")
    LIVE_BET_AMOUNT: float = float(os.getenv("LIVE_BET_AMOUNT", "100.0"))
    LIVE_LOWER_LIMIT: float = float(os.getenv("LIVE_LOWER_LIMIT", "0.000"))
    LIVE_UPPER_LIMIT: float = float(os.getenv("LIVE_UPPER_LIMIT", "0.070"))
    LIVE_BET_LIMIT: float = float(os.getenv("LIVE_BET_LIMIT", "0.10"))
    LIVE_ODDS_LIMIT: float = float(os.getenv("LIVE_ODDS_LIMIT", "750.0"))
    LIVE_SCAN_INTERVAL: float = float(os.getenv("LIVE_SCAN_INTERVAL", "5.0"))
    LIVE_AUTO_EXECUTE: bool = os.getenv("LIVE_AUTO_EXECUTE", "false").lower() == "true"
    LIVE_MAX_CONCURRENT_SCRAPERS: int = int(os.getenv("LIVE_MAX_CONCURRENT_SCRAPERS", "2"))

    # UI Theme Settings (Desktop)
    # Carbon fiber background toggle and tile size (256/512/1024)
    CARBON_BG_ENABLED: bool = False
    CARBON_TILE: int = 256

    @classmethod
    def validate(cls) -> bool:
        """
        Validate configuration settings.

        Returns:
            True if configuration is valid
        """
        # Check if any providers are configured (only free SofaScore Scraper available)
        providers = cls.get_api_providers()
        if not providers or not any(p.get("enabled", False) for p in providers):
            logger.warning(
                "No API providers configured. Please configure SofaScore Scraper (free)."
            )
            return False
        # Basic sanity checks for enforced opportunity counts
        if cls.MIN_STARTUP_OPPORTUNITIES < 0 or cls.MIN_REFRESH_OPPORTUNITIES < 0:
            logger.warning("Minimum opportunity counts must be non-negative; using defaults.")
        if cls.SYNTHETIC_MAX_PROFIT_PERCENTAGE < cls.MIN_PROFIT_PERCENTAGE:
            logger.warning(
                "SYNTHETIC_MAX_PROFIT_PERCENTAGE is below MIN_PROFIT_PERCENTAGE; raising to match minimum."
            )
            cls.SYNTHETIC_MAX_PROFIT_PERCENTAGE = cls.MIN_PROFIT_PERCENTAGE
        # Enforce real-data-only policy: never allow synthetic generation when enabled
        try:
            if cls.get_real_data_only():
                # If any path attempts to generate synthetic data, force it off
                if cls.get_synthesize_opportunities():
                    logger.warning(
                        "REAL_DATA_ONLY is enabled — disabling synthetic opportunities generation."
                    )
                    # Do not silently persist user config here; enforce at runtime
                    cls.SYNTHESIZE_OPPORTUNITIES_WHEN_LOW = False
        except Exception:
            # If enforcement fails, proceed but keep synthetic disabled by default
            cls.SYNTHESIZE_OPPORTUNITIES_WHEN_LOW = False

        return True

    @classmethod
    def save_api_key(cls, api_key: str, provider_name: str = "the_odds_api"):
        """Save API key to environment file."""
        env_file = ".env"
        lines = []

        if os.path.exists(env_file):
            with open(env_file) as f:
                lines = f.readlines()

        # Update or add API key
        env_key = f"{provider_name.upper()}_API_KEY"
        if provider_name == "the_odds_api":
            env_key = "ODDS_API_KEY"

        found = False
        for i, line in enumerate(lines):
            if line.startswith(f"{env_key}=") or (
                provider_name == "the_odds_api" and line.startswith("ODDS_API_KEY=")
            ):
                lines[i] = f"{env_key}={api_key}\n"
                found = True
                break

        if not found:
            lines.append(f"{env_key}={api_key}\n")

        with open(env_file, "w") as f:
            f.writelines(lines)

        if provider_name == "the_odds_api":
            cls.ODDS_API_KEY = api_key
        logger.info(f"API key saved for {provider_name}")

    @classmethod
    def get_bookmakers(cls) -> list[dict[str, str]]:
        """
        Get list of configured bookmakers.

        Returns:
            List of bookmaker dictionaries with name and optional username
        """
        if not os.path.exists(BOOKMAKERS_FILE):
            return []

        try:
            with open(BOOKMAKERS_FILE) as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading bookmakers: {str(e)}")
            return []

    @classmethod
    def save_bookmakers(cls, bookmakers: list[dict[str, str]]):
        """
        Save bookmaker list to configuration file.

        Args:
            bookmakers: List of bookmaker dictionaries
        """
        os.makedirs(CONFIG_DIR, exist_ok=True)

        with open(BOOKMAKERS_FILE, "w") as f:
            json.dump(bookmakers, f, indent=2)

        logger.info(f"Saved {len(bookmakers)} bookmakers to configuration")

    @classmethod
    def add_bookmaker(cls, name: str, username: str = ""):
        """
        Add a bookmaker to the configuration.

        Args:
            name: Bookmaker name
            username: Optional account username
        """
        bookmakers = cls.get_bookmakers()

        # Check if already exists
        for bm in bookmakers:
            if bm.get("name", "").lower() == name.lower():
                # Update existing
                bm["username"] = username
                cls.save_bookmakers(bookmakers)
                return

        # Add new
        bookmakers.append({"name": name, "username": username})
        cls.save_bookmakers(bookmakers)

    @classmethod
    def remove_bookmaker(cls, name: str):
        """
        Remove a bookmaker from configuration.

        Args:
            name: Bookmaker name to remove
        """
        bookmakers = cls.get_bookmakers()
        bookmakers = [bm for bm in bookmakers if bm.get("name", "").lower() != name.lower()]
        cls.save_bookmakers(bookmakers)

    @classmethod
    def get_preferred_sports(cls) -> list[str]:
        """Get list of preferred sports."""
        if not os.path.exists(CONFIG_FILE):
            return ["soccer", "basketball", "baseball", "hockey", "tennis"]

        try:
            with open(CONFIG_FILE) as f:
                config = json.load(f)
                return config.get(
                    "preferred_sports", ["soccer", "basketball", "baseball", "hockey", "tennis"]
                )
        except Exception:
            return ["soccer", "basketball", "baseball", "hockey", "tennis"]

    @classmethod
    def save_preferred_sports(cls, sports: list[str]):
        """Save preferred sports list."""
        os.makedirs(CONFIG_DIR, exist_ok=True)

        config = {}
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE) as f:
                    config = json.load(f)
            except Exception:
                pass

        config["preferred_sports"] = sports

        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)

    # ----- Carbon Background Settings -----
    @classmethod
    def get_carbon_bg_enabled(cls) -> bool:
        """Return whether the carbon fiber background is enabled (desktop app)."""
        # Environment override if provided
        env_val = os.getenv("CARBON_BG_ENABLED")
        if env_val is not None:
            try:
                return env_val.strip().lower() in {"1", "true", "yes"}
            except Exception:
                pass

        if not os.path.exists(CONFIG_FILE):
            return cls.CARBON_BG_ENABLED

        try:
            with open(CONFIG_FILE) as f:
                config = json.load(f)
                return bool(config.get("carbon_bg_enabled", cls.CARBON_BG_ENABLED))
        except Exception:
            return cls.CARBON_BG_ENABLED

    @classmethod
    def get_carbon_tile(cls) -> int:
        """Return preferred carbon tile size in pixels (256, 512, or 1024)."""
        env_val = os.getenv("CARBON_TILE")
        if env_val is not None:
            try:
                parsed = int(env_val)
                if parsed in (256, 512, 1024):
                    return parsed
            except Exception:
                pass

        if not os.path.exists(CONFIG_FILE):
            return cls.CARBON_TILE

        try:
            with open(CONFIG_FILE) as f:
                config = json.load(f)
                tile = int(config.get("carbon_tile", cls.CARBON_TILE))
                if tile not in (256, 512, 1024):
                    tile = cls.CARBON_TILE
                return tile
        except Exception:
            return cls.CARBON_TILE

    @classmethod
    def save_carbon_bg_enabled(cls, enabled: bool):
        """Persist carbon background enabled flag to bot_config.json."""
        os.makedirs(CONFIG_DIR, exist_ok=True)
        config = {}
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE) as f:
                    config = json.load(f)
            except Exception:
                pass
        config["carbon_bg_enabled"] = bool(enabled)
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
        # Update class value
        cls.CARBON_BG_ENABLED = bool(enabled)

    @classmethod
    def save_carbon_tile(cls, tile: int):
        """Persist carbon tile size (256/512/1024) to bot_config.json."""
        if tile not in (256, 512, 1024):
            tile = 256
        os.makedirs(CONFIG_DIR, exist_ok=True)
        config = {}
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE) as f:
                    config = json.load(f)
            except Exception:
                pass
        config["carbon_tile"] = int(tile)
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
        # Update class value
        cls.CARBON_TILE = int(tile)

    @classmethod
    def get_api_providers(cls) -> list[dict[str, any]]:
        """
        Get list of configured API providers.

        Returns:
            List of provider configuration dictionaries
        """
        if not os.path.exists(CONFIG_FILE):
            # Default: SofaScore Scraper (free)
            return [
                {
                    "name": "sofascore_scraper",
                    "type": "sofascore_scraper",
                    "api_key": "",  # Not needed for SofaScore
                    "priority": 1,
                    "enabled": True,  # Enabled by default since it's free
                }
            ]

        try:
            with open(CONFIG_FILE) as f:
                config = json.load(f)
                providers = config.get("api_providers", [])

                # If no providers configured, return default (SofaScore Scraper)
                if not providers:
                    return [
                        {
                            "name": "sofascore_scraper",
                            "type": "sofascore_scraper",
                            "api_key": "",  # Not needed for SofaScore
                            "priority": 1,
                            "enabled": True,  # Enabled by default since it's free
                        }
                    ]

                return providers
        except Exception as e:
            logger.error(f"Error loading API providers: {e}")
            # Return default SofaScore Scraper on error
            return [
                {
                    "name": "sofascore_scraper",
                    "type": "sofascore_scraper",
                    "api_key": "",  # Not needed for SofaScore
                    "priority": 1,
                    "enabled": True,  # Enabled by default since it's free
                }
            ]

    @classmethod
    def save_api_providers(cls, providers: list[dict[str, any]]):
        """
        Save API provider configuration.

        Args:
            providers: List of provider configuration dictionaries
        """
        os.makedirs(CONFIG_DIR, exist_ok=True)

        config = {}
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE) as f:
                    config = json.load(f)
            except Exception:
                pass

        config["api_providers"] = providers

        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)

        logger.info(f"Saved {len(providers)} API provider configurations")

    # ----- Synthetic Opportunities Toggle -----
    @classmethod
    def get_synthesize_opportunities(cls) -> bool:
        """Return whether synthetic opportunities should be generated when data is low.

        Priority: ENV override -> bot_config.json -> class default (False).
        """
        # Hard override if REAL_DATA_ONLY policy is active
        try:
            if cls.get_real_data_only():
                return False
        except Exception:
            # If policy check fails, continue normal resolution
            pass
        # ENV override
        env_val = os.getenv("SYNTHESIZE_OPPORTUNITIES_WHEN_LOW")
        if env_val is not None:
            try:
                return env_val.strip().lower() in {"1", "true", "yes"}
            except Exception:
                pass

        # bot_config.json
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE) as f:
                    config = json.load(f)
                    if "synthesize_opportunities" in config:
                        return bool(config.get("synthesize_opportunities", False))
        except Exception:
            # Fall back to class value
            pass

        return bool(cls.SYNTHESIZE_OPPORTUNITIES_WHEN_LOW)

    @classmethod
    def save_synthesize_opportunities(cls, enabled: bool):
        """Persist synthetic opportunities toggle to bot_config.json and update class value."""
        os.makedirs(CONFIG_DIR, exist_ok=True)
        config: dict[str, any] = {}
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE) as f:
                    config = json.load(f)
            except Exception:
                config = {}
        # Respect REAL_DATA_ONLY policy: never persist a True value when policy is enabled
        if cls.get_real_data_only():
            enabled = False
        config["synthesize_opportunities"] = bool(enabled)
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
        cls.SYNTHESIZE_OPPORTUNITIES_WHEN_LOW = bool(enabled)
        logger.info(f"Synthetic opportunities {'enabled' if enabled else 'disabled'} and saved")

    # ----- Real-Data-Only Policy -----
    @classmethod
    def get_real_data_only(cls) -> bool:
        """Return whether real-data-only policy is enforced.

        Priority: ENV override -> bot_config.json -> class default (True).
        """
        # ENV override
        env_val = os.getenv("REAL_DATA_ONLY")
        if env_val is not None:
            try:
                return env_val.strip().lower() in {"1", "true", "yes"}
            except Exception:
                pass

        # bot_config.json
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE) as f:
                    config = json.load(f)
                    if "real_data_only" in config:
                        return bool(config.get("real_data_only", True))
        except Exception:
            # Fall back to class value
            pass

        return bool(cls.REAL_DATA_ONLY)

    @classmethod
    def save_real_data_only(cls, enabled: bool):
        """Persist real-data-only policy toggle to bot_config.json and update class value.

        Security: This flag hard-disables any synthetic/top-up generation paths.
        """
        os.makedirs(CONFIG_DIR, exist_ok=True)
        config: dict[str, any] = {}
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE) as f:
                    config = json.load(f)
            except Exception:
                config = {}
        config["real_data_only"] = bool(enabled)
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
        cls.REAL_DATA_ONLY = bool(enabled)
        # If enabling policy, immediately disable synthetic paths in memory
        if enabled:
            cls.SYNTHESIZE_OPPORTUNITIES_WHEN_LOW = False
        logger.info(
            f"Real-data-only policy {'enabled' if enabled else 'disabled'} and saved"
        )
