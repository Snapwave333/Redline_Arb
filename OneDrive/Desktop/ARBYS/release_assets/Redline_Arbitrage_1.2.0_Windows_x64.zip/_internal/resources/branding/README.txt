Redline Arbitrage Branding Suite
---------------------------------
Includes all icon, logo, and color/typography references for consistent usage.

Icons (.ico / .svg):
- Primary, Dark, Flat, and White variants
- All standard resolutions

Logos (.svg / .png):
- Horizontal text logo (flat red + white palette)
- Stacked variant for compact spaces
- Monochrome and dark-mode options

Brand Colors:
- Primary Red: #FF0033
- Dark Red: #D00000
- Carbon Black: #0D0D0F
- Text White: #FFFFFF
- Muted Gray: #9AA0A6

Fonts:
- Rajdhani (headings)
- Orbitron (accent)
- System sans-serif fallback

Created for Redline Arbitrage desktop and marketing integration.
