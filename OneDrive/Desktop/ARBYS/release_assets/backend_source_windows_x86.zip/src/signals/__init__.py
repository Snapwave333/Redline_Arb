# Signals package

from src.signals.injury_signal import InjurySignalDetector

__all__ = [
    "InjurySignalDetector",
]
