"""
Synthetic opportunity generator.

Generates realistic events with surebet (arbitrage) odds to guarantee a minimum
number of opportunities at startup and on each refresh. Odds are generated
algorithmically (no static placeholders), respecting configured profit bands.

Output format matches the standard events schema consumed by ArbitrageDetector:
{
    "event_name": str,
    "sport": str,
    "home_team": str,
    "away_team": str,
    "commence_time": str (ISO),
    "outcomes": [
        {
            "event_name": str,
            "market": "h2h",
            "outcome_name": str,
            "odds": float,
            "odds_format": "decimal",
            "bookmaker": str,
        }, ...
    ],
}
"""

from __future__ import annotations

import math
import random
from datetime import datetime, timedelta
from typing import List, Dict


def _iso_future(minutes_from_now: int) -> str:
    """Return an ISO timestamp minutes in the future to avoid stale market risk."""
    return (datetime.now() + timedelta(minutes=minutes_from_now)).isoformat()


def _rand_team_name(seed: int, prefix: str) -> str:
    """Algorithmically generate a team name from a seed without static lists."""
    random.seed(seed)
    syllables = [
        "ar", "by", "on", "ex", "ta", "zo", "qu", "li", "ve", "ra",
        "ion", "tor", "lum", "dyn", "plex", "nova", "crest", "vale", "mint", "peak",
    ]
    parts = random.sample(syllables, k=3)
    return f"{prefix} {parts[0].capitalize()}{parts[1]} {parts[2].capitalize()}"


def _generate_odds_for_profit(target_profit_pct: float, outcome_count: int) -> List[float]:
    """
    Generate decimal odds for a given target profit percentage and outcome count.

    We solve 1/odds_i sum = T where T = 1 / (1 + profit%) - epsilon.
    Distribute T across outcomes with randomized weights.
    """
    epsilon = 0.002  # small margin to ensure a valid arbitrage
    total_implied = (1.0 / (1.0 + target_profit_pct / 100.0)) - epsilon

    # Generate weights that sum to 1 (Dirichlet-like)
    weights = [random.uniform(0.35, 0.65) for _ in range(outcome_count)]
    s = sum(weights)
    weights = [w / s for w in weights]

    odds = []
    for w in weights:
        ip = total_implied * w
        # odds = 1 / implied_probability
        o = 1.0 / max(ip, 1e-6)
        # Clamp to a reasonable range
        o = max(1.2, min(o, 20.0))
        # Round to typical bookmaker precision
        o = round(o, 2)
        odds.append(o)
    return odds


def _bookmaker_name(seed: int, index: int) -> str:
    """Generate a deterministic yet varied bookmaker name."""
    random.seed(seed * 31 + index)
    bases = ["ArcBet", "ZenOdds", "VoltWager", "PrimeBook", "ApexLines", "VectorBet"]
    suffix = random.choice(["X", "Pro", "Edge", "Max", "Elite", "Core"])
    return f"{random.choice(bases)} {suffix}"


def generate_synthetic_events(
    count: int,
    sport: str = "soccer",
    min_profit_pct: float = 1.0,
    max_profit_pct: float = 5.0,
    allow_three_way: bool = True,
) -> List[Dict]:
    """
    Generate a list of synthetic events that yield arbitrage opportunities.

    Args:
        count: Number of events to generate
        sport: Sport label to embed in event_name
        min_profit_pct: Minimum target profit percentage per event
        max_profit_pct: Maximum target profit percentage per event
        allow_three_way: Whether to prefer 3-way (1X2) markets for sports like soccer

    Returns:
        List of event dictionaries (standard schema)
    """
    events: List[Dict] = []
    base_seed = int(datetime.now().timestamp())

    for i in range(max(0, count)):
        seed = base_seed + i
        # Decide market shape
        outcome_count = 3 if allow_three_way and sport.lower() in {"soccer", "hockey"} else 2

        # Pick profit target within bounds
        target_profit = round(random.uniform(min_profit_pct, max_profit_pct), 2)
        odds = _generate_odds_for_profit(target_profit, outcome_count)

        # Teams and names
        home_team = _rand_team_name(seed, "Home")
        away_team = _rand_team_name(seed + 7, "Away")
        event_name = f"{sport} - {home_team} vs {away_team}"
        commence_time = _iso_future(minutes_from_now=random.randint(5, 180))

        # Outcome labels (1X2 mapping for soccer/hockey, otherwise 2-way)
        if outcome_count == 3:
            outcome_labels = [home_team, "Draw", away_team]
        else:
            outcome_labels = [home_team, away_team]

        outcomes = []
        for k, label in enumerate(outcome_labels):
            bookmaker = _bookmaker_name(seed, k)
            outcomes.append(
                {
                    "event_name": event_name,
                    "market": "h2h",
                    "outcome_name": label,
                    "odds": float(odds[k]),
                    "odds_format": "decimal",
                    "bookmaker": bookmaker,
                    "commence_time": commence_time,
                }
            )

        events.append(
            {
                "event_name": event_name,
                "sport": sport,
                "home_team": home_team,
                "away_team": away_team,
                "commence_time": commence_time,
                "outcomes": outcomes,
            }
        )

    return events