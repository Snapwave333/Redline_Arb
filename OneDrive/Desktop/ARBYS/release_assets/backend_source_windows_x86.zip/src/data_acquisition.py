"""
Data acquisition module for fetching odds data from various sources.

Provides:
- OddsDataFetcher: simple fetcher for a single provider/key (stubbed for tests)
- OrchestratedDataFetcher: orchestrates multiple providers via a passed orchestrator
"""

import logging
from typing import List, Optional, Dict, Any

# Define OddsData type for compatibility
OddsData = Dict[str, Any]

logger = logging.getLogger(__name__)


class OddsDataFetcher:
    """Simple odds data fetcher for a single provider.

    This class exists primarily to satisfy integration tests that validate
    initialization and a minimal fetch_odds interface. In production, odds
    are obtained via orchestrators/providers configured elsewhere.
    """

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key

    def fetch_odds(self, sport: str = "soccer") -> List[OddsData]:
        """Fetch odds for the given sport.

        For tests, return an empty list to indicate a valid response shape
        without performing network operations.
        """
        logger.debug(f"OddsDataFetcher.fetch_odds called for sport={sport}")
        return []


class OrchestratedDataFetcher:
    """Data fetcher that orchestrates multiple API providers."""

    def __init__(self, orchestrator):
        """Initialize with orchestrator."""
        self.orchestrator = orchestrator

    def fetch_odds_sync(self, sport: str = "soccer") -> List[OddsData]:
        """Fetch odds data synchronously."""
        try:
            merged_results, errors, latency_stats = self.orchestrator.fetch_odds(sport=sport)
            return merged_results
        except Exception as e:
            logger.error(f"Error fetching odds: {e}")
            return []

    def fetch_odds(self, sport: str = "soccer") -> List[OddsData]:
        """Fetch odds data asynchronously."""
        return self.fetch_odds_sync(sport)
