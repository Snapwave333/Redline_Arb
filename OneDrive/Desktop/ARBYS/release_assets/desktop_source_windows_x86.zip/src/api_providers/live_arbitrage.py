"""
Live arbitrage provider using web scraping with Selenium.
Integrates the live sports arbitrage finder functionality.
"""

import logging
import time
from typing import Any, Dict, List, Optional

import nashpy as nash
import numpy as np
from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException
from selenium.webdriver.common.by import By

from src.api_providers.base import OddsAPIProvider, StandardizedOdds

logger = logging.getLogger(__name__)

try:
    import undetected_chromedriver as uc
    from selenium.webdriver.common.keys import Keys
except ImportError as e:
    logger.error(f"Missing required dependencies for live arbitrage: {e}")
    raise ImportError("Live arbitrage requires: undetected-chromedriver and selenium")

# Optional: gevent for parallel scraping
try:
    import gevent
    from gevent.pool import Pool
except Exception:
    gevent = None
    Pool = None


class LiveArbFinder:
    """Live arbitrage finder using Selenium web scraping."""

    def __init__(self, url: str, sport: str = "Baseball"):
        """
        Initialize the arbitrage finder.

        Args:
            url: URL to scrape
            sport: Sport to monitor
        """
        self.url = url
        self.sport = sport
        self.driver = None
        self._initialize_driver()

    def _initialize_driver(self):
        """Initialize the undetected Chrome driver."""
        try:
            self.driver = uc.Chrome()
            self.driver.implicitly_wait(5)
            self.driver.get(self.url)
            logger.info(f"Initialized driver for {self.url}")
        except Exception as e:
            logger.error(f"Failed to initialize driver: {e}")
            raise

    def set_type(self, ask: bool = False, bid: bool = True):
        """
        Set the view type (ASK or BID).

        Args:
            ask: Whether to use ASK view
            bid: Whether to use BID view
        """
        try:
            if ask:
                self.type = "ASK"
                xpath = f"//a[contains(@href,'/live')]//span[text()='{self.sport}']"
                self.driver.find_element(By.XPATH, xpath).click()
            elif bid:
                self.type = "BID"
                xpath = "//a[@role='tab']/span[text()='{self.sport}']"
                self.driver.find_element(By.XPATH, xpath).click()
        except Exception as e:
            logger.warning(f"Failed to set view type: {e}")

    def get_live_odds(self) -> Dict[str, List]:
        """
        Scrape live odds from the current page.

        Returns:
            Dictionary mapping event keys to odds data
        """
        odds_data = {}

        try:
            # Find all live events
            results = self.driver.find_elements(
                By.XPATH, "(//tbody[@class='sportsbook-table__body'])[1]//tr"
            )

            for i in range(0, len(results), 2):
                if i + 1 >= len(results):
                    break

                team1_row, team2_row = results[i], results[i + 1]

                # Extract team names
                team1_name = team1_row.find_element(By.XPATH, self._get_team_name_xpath()).text
                team2_name = team2_row.find_element(By.XPATH, self._get_team_name_xpath()).text

                # Normalize team names
                team1_name = self._normalize_team_name(team1_name)
                team2_name = self._normalize_team_name(team2_name)

                # Extract wager elements
                team1_wagers = team1_row.find_elements(By.XPATH, self._get_wager_xpath())
                team2_wagers = team2_row.find_elements(By.XPATH, self._get_wager_xpath())

                # Extract odds for different markets
                odds_list = []
                for j in range(min(3, len(team1_wagers))):  # Usually 3 markets
                    try:
                        team1_odds = self._extract_odds(team1_wagers[j])
                        team2_odds = self._extract_odds(team2_wagers[j])
                        odds_list.append([team1_odds, team2_odds])
                    except (IndexError, AttributeError):
                        continue

                if odds_list and team1_name and team2_name:
                    event_key = f"{team1_name.lower()} vs {team2_name.lower()}"
                    odds_data[event_key] = odds_list + [team1_name, team2_name]

        except Exception as e:
            logger.error(f"Error scraping live odds: {e}")

        return odds_data

    def _get_team_name_xpath(self) -> str:
        """Get XPath for team names."""
        return ".//div[@class='event-cell__name-text']"

    def _get_wager_xpath(self) -> str:
        """Get XPath for wager elements."""
        return ".//td[contains(@class,'sportsbook-table__column-row')]"

    def _normalize_team_name(self, name: str) -> str:
        """Normalize team name for matching."""
        name = name.strip()
        if 'Sox' in name:
            return ' '.join(name.split(' ')[-2:])
        else:
            return name.split(' ')[-1]

    def _extract_odds(self, element) -> float:
        """Extract odds value from element."""
        try:
            text = element.text.replace('\n', ' ').replace('  ', ' ').strip()
            if not text or 'disabled' in element.get_attribute('innerHTML'):
                return 0.0

            # Parse odds (handle American format)
            if text.startswith('+') or text.startswith('-'):
                odds = float(text)
                if odds < 0:
                    return 100 / -odds * 100
                else:
                    return odds
            else:
                return float(text)
        except (ValueError, AttributeError):
            return 0.0

    def close(self):
        """Close the browser driver."""
        if self.driver:
            try:
                self.driver.quit()
            except Exception as e:
                logger.warning(f"Error closing driver: {e}")


class LiveArbitrageProvider(OddsAPIProvider):
    """Live arbitrage provider using web scraping."""

    def __init__(
        self,
        enabled: bool = True,
        priority: int = 1,
        bet_amount: float = 100.0,
        lower_limit: float = 0.000,
        upper_limit: float = 0.070,
        bet_limit: float = 0.10,
        odds_limit: float = 750.0,
        sport: str = "Baseball",
    ):
        """
        Initialize live arbitrage provider.

        Args:
            enabled: Whether provider is enabled
            priority: Priority level
            bet_amount: Total amount to wager
            lower_limit: Lower arbitrage limit as percentage
            upper_limit: Upper arbitrage limit as percentage
            bet_limit: Minimum bet amount
            odds_limit: Maximum odds limit
            sport: Sport to monitor
        """
        super().__init__("", enabled, priority)  # No API key needed
        self.bet_amount = bet_amount
        self.lower_limit = lower_limit
        self.upper_limit = upper_limit
        self.bet_limit = bet_limit
        self.odds_limit = odds_limit
        self.sport = sport

        # Initialize scrapers for different sites
        self.ask_scraper = None  # FanDuel
        self.bid_scraper = None  # DraftKings
        # Initialize scrapers only when provider is enabled to avoid driver creation in disabled state
        if self.enabled:
            self._initialize_scrapers()

    def _initialize_scrapers(self):
        """Initialize the web scrapers."""
        try:
            self.ask_scraper = LiveArbFinder('https://sportsbook.fanduel.com/live', self.sport)
            self.ask_scraper.set_type(ask=True, bid=False)

            self.bid_scraper = LiveArbFinder('https://sportsbook.draftkings.com/live', self.sport)
            self.bid_scraper.set_type(ask=False, bid=True)

            logger.info("Initialized live arbitrage scrapers")
        except Exception as e:
            logger.error(f"Failed to initialize scrapers: {e}")
            self.ask_scraper = None
            self.bid_scraper = None

    def get_provider_name(self) -> str:
        """Return provider identifier."""
        return "live_arbitrage"

    def fetch_odds(self, sport: str = "baseball", **kwargs) -> List[Dict]:
        """
        Fetch live arbitrage opportunities.

        Args:
            sport: Sport to fetch odds for
            **kwargs: Additional parameters

        Returns:
            List of standardized event dictionaries with arbitrage data
        """
        if not self.enabled or not self.ask_scraper or not self.bid_scraper:
            return []

        start_time = time.time()

        try:
            # Scrape odds from both sites
            if Pool is not None:
                # Parallel with gevent when available
                pool = Pool(2)
                ask_data = pool.apply_async(self.ask_scraper.get_live_odds)
                bid_data = pool.apply_async(self.bid_scraper.get_live_odds)
                pool.join()
                ask_odds = ask_data.get()
                bid_odds = bid_data.get()
            else:
                # Fallback to sequential scraping without gevent
                ask_odds = self.ask_scraper.get_live_odds()
                bid_odds = self.bid_scraper.get_live_odds()

            # Find matching events
            matched_events = self._find_arbitrage_opportunities(ask_odds, bid_odds)

            response_time = time.time() - start_time
            self.update_health(True, response_time)

            return matched_events

        except Exception as e:
            error_msg = f"Error fetching live arbitrage data: {str(e)}"
            logger.error(error_msg)
            response_time = time.time() - start_time
            self.update_health(False, response_time, error_msg)
            return []

    def _find_arbitrage_opportunities(self, ask_data: Dict, bid_data: Dict) -> List[Dict]:
        """
        Find arbitrage opportunities between ASK and BID data.

        Args:
            ask_data: Odds data from ASK site
            bid_data: Odds data from BID site

        Returns:
            List of events with arbitrage opportunities
        """
        opportunities = []

        # Find common events
        common_events = set(ask_data.keys()) & set(bid_data.keys())

        for event_key in common_events:
            ask_event = ask_data[event_key]
            bid_event = bid_data[event_key]

            team1, team2 = ask_event[-2], ask_event[-1]

            # Check each market for arbitrage
            for market_idx in range(min(len(ask_event) - 2, len(bid_event) - 2)):
                ask_market = ask_event[market_idx]
                bid_market = bid_event[market_idx]

                # Check both outcomes for arbitrage
                for outcome_idx in range(2):
                    ask_odds = ask_market[outcome_idx]
                    bid_odds = bid_market[1 - outcome_idx]  # Opposite outcome

                    if ask_odds > 0 and bid_odds > 0:
                        arbitrage_data = self._calculate_arbitrage(
                            ask_odds, bid_odds, team1, team2, market_idx, outcome_idx
                        )

                        if arbitrage_data:
                            opportunities.append(arbitrage_data)

        return opportunities

    def _calculate_arbitrage(
        self, ask_odds: float, bid_odds: float, team1: str, team2: str,
        market_idx: int, outcome_idx: int
    ) -> Optional[Dict]:
        """
        Calculate Nash equilibrium for arbitrage opportunity.

        Args:
            ask_odds: Odds from ASK site
            bid_odds: Odds from BID site
            team1: Home team name
            team2: Away team name
            market_idx: Market index
            outcome_idx: Outcome index

        Returns:
            Arbitrage opportunity data or None
        """
        try:
            # Create payoff matrix
            A = np.array([
                [ask_odds / 100, -1],
                [-1, bid_odds / 100]
            ])

            # Calculate Nash equilibrium
            game = nash.Game(A)
            equilibria = list(game.support_enumeration())

            if not equilibria:
                return None

            equilibrium = equilibria[0][0]

            # Calculate bet amounts
            bet_amounts = self.bet_amount * equilibrium
            bet_amounts = [round(x, 2) for x in bet_amounts]

            # Calculate returns
            returns = []
            total_return = 0

            for i, bet in enumerate(bet_amounts):
                outcome_return = bet * A[i][i] / 100 + bet
                returns.append(outcome_return)
                total_return += outcome_return

            avg_return = total_return / len(bet_amounts)
            profit_percentage = (avg_return / sum(bet_amounts)) - 1

            # Check arbitrage conditions
            if (bet_amounts[0] >= self.bet_limit and
                bet_amounts[1] >= self.bet_limit and
                profit_percentage >= self.lower_limit and
                profit_percentage <= self.upper_limit and
                ask_odds <= self.odds_limit and
                bid_odds <= self.odds_limit):

                return {
                    "event_name": f"{self.sport} - {team1} vs {team2}",
                    "sport": self.sport,
                    "home_team": team1,
                    "away_team": team2,
                    "commence_time": "LIVE",  # Live events don't have future commence time
                    "arbitrage_opportunity": {
                        "profit_percentage": profit_percentage,
                        "ask_odds": ask_odds,
                        "bid_odds": bid_odds,
                        "ask_bet_amount": bet_amounts[0],
                        "bid_bet_amount": bet_amounts[1],
                        "expected_return": avg_return,
                        "market_type": self._get_market_type(market_idx),
                        "outcome": "home" if outcome_idx == 0 else "away",
                        "ask_site": "FanDuel",
                        "bid_site": "DraftKings",
                    },
                    "outcomes": [
                        {
                            "event_name": f"{self.sport} - {team1} vs {team2}",
                            "market": self._get_market_type(market_idx),
                            "outcome_name": team1 if outcome_idx == 0 else team2,
                            "odds": ask_odds,
                            "odds_format": "american",
                            "bookmaker": "FanDuel (ASK)",
                        },
                        {
                            "event_name": f"{self.sport} - {team1} vs {team2}",
                            "market": self._get_market_type(market_idx),
                            "outcome_name": team2 if outcome_idx == 0 else team1,
                            "odds": bid_odds,
                            "odds_format": "american",
                            "bookmaker": "DraftKings (BID)",
                        }
                    ]
                }

        except Exception as e:
            logger.warning(f"Error calculating arbitrage: {e}")

        return None

    def _get_market_type(self, market_idx: int) -> str:
        """Get market type name from index."""
        markets = ["moneyline", "spread", "total"]
        return markets[market_idx] if market_idx < len(markets) else "unknown"

    def normalize_response(self, raw_data: Any) -> List[Dict]:
        """
        Normalize live arbitrage data to standard format.

        Args:
            raw_data: Raw arbitrage data

        Returns:
            List of standardized event dictionaries
        """
        # Data is already normalized in fetch_odds
        return raw_data if isinstance(raw_data, list) else []

    def close(self):
        """Close all browser drivers."""
        if self.ask_scraper:
            self.ask_scraper.close()
        if self.bid_scraper:
            self.bid_scraper.close()
