"""
Live data orchestrator for real-time arbitrage detection.
Specializes in coordinating live scraping providers and arbitrage calculations.
"""

import logging
import time
from datetime import datetime
from typing import Dict, List, Optional

from src.api_providers.live_arbitrage import LiveArbitrageProvider
from src.data_orchestrator import MultiAPIOrchestrator
from src.nash_equilibrium import ArbitrageCalculator

logger = logging.getLogger(__name__)


class LiveDataOrchestrator:
    """
    Orchestrator specifically for live arbitrage data.
    Handles real-time scraping, arbitrage detection, and bet execution.
    """

    def __init__(
        self,
        live_provider: LiveArbitrageProvider,
        arbitrage_calculator: Optional[ArbitrageCalculator] = None,
        auto_execute: bool = False,
        max_concurrent_scrapers: int = 2,
    ):
        """
        Initialize live data orchestrator.

        Args:
            live_provider: Live arbitrage provider instance
            arbitrage_calculator: Optional arbitrage calculator
            auto_execute: Whether to automatically execute profitable bets
            max_concurrent_scrapers: Maximum concurrent scrapers
        """
        self.live_provider = live_provider
        self.arbitrage_calculator = arbitrage_calculator or ArbitrageCalculator()
        self.auto_execute = auto_execute
        self.max_concurrent_scrapers = max_concurrent_scrapers

        self.is_running = False
        self.last_scan_time = None
        self.scan_interval = 5.0  # seconds between scans
        self.opportunities_found = []
        self.executed_bets = []

        # Performance tracking
        self.scan_count = 0
        self.opportunities_count = 0
        self.execution_count = 0
        self.total_profit = 0.0

    def start_live_monitoring(self, sport: str = "baseball") -> None:
        """
        Start live monitoring for arbitrage opportunities.

        Args:
            sport: Sport to monitor
        """
        if self.is_running:
            logger.warning("Live monitoring already running")
            return

        self.is_running = True
        self.sport = sport
        logger.info(f"Started live arbitrage monitoring for {sport}")

        try:
            while self.is_running:
                self._perform_scan()
                time.sleep(self.scan_interval)
        except KeyboardInterrupt:
            logger.info("Live monitoring stopped by user")
        except Exception as e:
            logger.error(f"Error in live monitoring: {e}")
        finally:
            self.stop_live_monitoring()

    def stop_live_monitoring(self) -> None:
        """Stop live monitoring and cleanup resources."""
        self.is_running = False
        if hasattr(self.live_provider, 'close'):
            self.live_provider.close()
        logger.info("Stopped live arbitrage monitoring")

    def perform_single_scan(self, sport: str = "baseball") -> Dict:
        """
        Perform a single scan for arbitrage opportunities.

        Args:
            sport: Sport to scan

        Returns:
            Scan results dictionary
        """
        self.scan_count += 1
        self.last_scan_time = datetime.now()

        try:
            # Fetch live arbitrage data
            opportunities = self.live_provider.fetch_odds(sport)

            # Process opportunities
            processed_opportunities = []
            for opportunity in opportunities:
                processed = self._process_arbitrage_opportunity(opportunity)
                if processed:
                    processed_opportunities.append(processed)
                    self.opportunities_count += 1

            # Auto-execute if enabled
            if self.auto_execute:
                for opp in processed_opportunities:
                    if self._should_execute_bet(opp):
                        self._execute_bet(opp)

            scan_result = {
                "scan_id": self.scan_count,
                "timestamp": self.last_scan_time.isoformat(),
                "sport": sport,
                "opportunities_found": len(processed_opportunities),
                "opportunities": processed_opportunities,
                "executed_bets": len([opp for opp in processed_opportunities if opp.get("executed", False)]),
                "performance": self.get_performance_stats(),
            }

            return scan_result

        except Exception as e:
            logger.error(f"Error during single scan: {e}")
            return {
                "scan_id": self.scan_count,
                "timestamp": self.last_scan_time.isoformat(),
                "sport": sport,
                "error": str(e),
                "opportunities_found": 0,
                "opportunities": [],
                "executed_bets": 0,
            }

    def _perform_scan(self) -> None:
        """Internal method to perform a scan."""
        result = self.perform_single_scan(self.sport)

        if result["opportunities_found"] > 0:
            logger.info(f"Found {result['opportunities_found']} arbitrage opportunities")
            self.opportunities_found.extend(result["opportunities"])

        # Keep only recent opportunities (last 100)
        if len(self.opportunities_found) > 100:
            self.opportunities_found = self.opportunities_found[-100:]

    def _process_arbitrage_opportunity(self, opportunity: Dict) -> Optional[Dict]:
        """
        Process a raw arbitrage opportunity into a standardized format.

        Args:
            opportunity: Raw opportunity data

        Returns:
            Processed opportunity data
        """
        try:
            arb_data = opportunity.get("arbitrage_opportunity", {})

            # Validate required fields
            required_fields = ["profit_percentage", "ask_bet_amount", "bid_bet_amount"]
            if not all(field in arb_data for field in required_fields):
                return None

            processed = {
                "event_name": opportunity.get("event_name", "Unknown Event"),
                "sport": opportunity.get("sport", "Unknown"),
                "home_team": opportunity.get("home_team", "Unknown"),
                "away_team": opportunity.get("away_team", "Unknown"),
                "commence_time": opportunity.get("commence_time", "LIVE"),
                "profit_percentage": arb_data["profit_percentage"],
                "ask_bet_amount": arb_data["ask_bet_amount"],
                "bid_bet_amount": arb_data["bid_bet_amount"],
                "expected_return": arb_data.get("expected_return", 0),
                "ask_odds": arb_data.get("ask_odds", 0),
                "bid_odds": arb_data.get("bid_odds", 0),
                "market_type": arb_data.get("market_type", "moneyline"),
                "outcome": arb_data.get("outcome", "unknown"),
                "ask_site": arb_data.get("ask_site", "Unknown"),
                "bid_site": arb_data.get("bid_site", "Unknown"),
                "discovered_at": datetime.now().isoformat(),
                "executed": False,
                "execution_result": None,
            }

            return processed

        except Exception as e:
            logger.warning(f"Error processing arbitrage opportunity: {e}")
            return None

    def _should_execute_bet(self, opportunity: Dict) -> bool:
        """
        Determine if a bet should be auto-executed.

        Args:
            opportunity: Processed opportunity data

        Returns:
            True if bet should be executed
        """
        if not self.auto_execute:
            return False

        # Check profit threshold (minimum 1% profit)
        if opportunity["profit_percentage"] < 1.0:
            return False

        # Check bet amounts (minimum $1 per bet)
        if opportunity["ask_bet_amount"] < 1.0 or opportunity["bid_bet_amount"] < 1.0:
            return False

        # Check odds limits
        if opportunity["ask_odds"] > 750 or opportunity["bid_odds"] > 750:
            return False

        return True

    def _execute_bet(self, opportunity: Dict) -> bool:
        """
        Execute a bet (placeholder for actual execution logic).

        Args:
            opportunity: Opportunity to execute

        Returns:
            True if execution was successful
        """
        try:
            # This is a placeholder - actual execution would require
            # integration with betting platforms and user confirmation
            logger.info(f"Auto-executing bet for {opportunity['event_name']}: "
                       f"${opportunity['ask_bet_amount']} on {opportunity['ask_site']}, "
                       f"${opportunity['bid_bet_amount']} on {opportunity['bid_site']}")

            # Mark as executed
            opportunity["executed"] = True
            opportunity["execution_result"] = {
                "status": "pending",
                "timestamp": datetime.now().isoformat(),
                "expected_profit": opportunity["expected_return"] - (
                    opportunity["ask_bet_amount"] + opportunity["bid_bet_amount"]
                )
            }

            self.executed_bets.append(opportunity)
            self.execution_count += 1

            # Keep only recent executions (last 50)
            if len(self.executed_bets) > 50:
                self.executed_bets = self.executed_bets[-50:]

            return True

        except Exception as e:
            logger.error(f"Error executing bet: {e}")
            opportunity["execution_result"] = {
                "status": "failed",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
            return False

    def get_performance_stats(self) -> Dict:
        """
        Get performance statistics.

        Returns:
            Performance statistics dictionary
        """
        total_scans = self.scan_count
        total_opportunities = self.opportunities_count
        total_executions = self.execution_count

        return {
            "total_scans": total_scans,
            "total_opportunities": total_opportunities,
            "total_executions": total_executions,
            "opportunities_per_scan": total_opportunities / max(total_scans, 1),
            "execution_rate": total_executions / max(total_opportunities, 1) * 100,
            "is_running": self.is_running,
            "last_scan_time": self.last_scan_time.isoformat() if self.last_scan_time else None,
        }

    def get_recent_opportunities(self, limit: int = 10) -> List[Dict]:
        """
        Get recent arbitrage opportunities.

        Args:
            limit: Maximum number of opportunities to return

        Returns:
            List of recent opportunities
        """
        return self.opportunities_found[-limit:] if self.opportunities_found else []

    def get_executed_bets(self, limit: int = 10) -> List[Dict]:
        """
        Get recently executed bets.

        Args:
            limit: Maximum number of bets to return

        Returns:
            List of executed bets
        """
        return self.executed_bets[-limit:] if self.executed_bets else []


class LiveArbitrageIntegration:
    """
    Integration layer between live arbitrage and existing ARBYS system.
    """

    def __init__(self, existing_orchestrator: MultiAPIOrchestrator):
        """
        Initialize integration layer.

        Args:
            existing_orchestrator: Existing MultiAPIOrchestrator instance
        """
        self.existing_orchestrator = existing_orchestrator
        self.live_orchestrator = None
        self.live_provider = None

    def add_live_arbitrage_provider(self, live_provider: LiveArbitrageProvider) -> None:
        """
        Add live arbitrage provider to the existing system.

        Args:
            live_provider: Live arbitrage provider instance
        """
        self.live_provider = live_provider
        self.existing_orchestrator.add_provider(live_provider)

        # Create live orchestrator
        self.live_orchestrator = LiveDataOrchestrator(live_provider)

        logger.info("Added live arbitrage provider to existing system")

    def get_combined_odds(self, sport: str, include_live_arbitrage: bool = True) -> Dict:
        """
        Get combined odds from all providers including live arbitrage.

        Args:
            sport: Sport to fetch odds for
            include_live_arbitrage: Whether to include live arbitrage data

        Returns:
            Combined results dictionary
        """
        # Get results from existing orchestrator
        results, errors, latency_stats = self.existing_orchestrator.fetch_odds(sport)

        combined_results = {
            "traditional_odds": results,
            "live_arbitrage": [],
            "errors": errors,
            "latency_stats": latency_stats,
        }

        # Add live arbitrage if enabled
        if include_live_arbitrage and self.live_provider and self.live_provider.is_enabled():
            try:
                live_opportunities = self.live_provider.fetch_odds(sport)
                combined_results["live_arbitrage"] = live_opportunities

                # Add live provider to latency stats
                if hasattr(self.live_provider, 'get_health'):
                    health = self.live_provider.get_health()
                    combined_results["latency_stats"]["live_arbitrage"] = {
                        "response_time": getattr(health, 'avg_response_time', 0),
                        "success": health.status == "healthy",
                        "result_count": len(live_opportunities),
                    }

            except Exception as e:
                logger.error(f"Error fetching live arbitrage: {e}")
                combined_results["errors"].append({
                    "provider": "live_arbitrage",
                    "error": str(e),
                    "timestamp": datetime.now().isoformat(),
                })

        return combined_results

    def start_live_monitoring(self, sport: str = "baseball") -> None:
        """
        Start live arbitrage monitoring.

        Args:
            sport: Sport to monitor
        """
        if self.live_orchestrator:
            self.live_orchestrator.start_live_monitoring(sport)
        else:
            logger.warning("Live orchestrator not initialized")

    def stop_live_monitoring(self) -> None:
        """Stop live arbitrage monitoring."""
        if self.live_orchestrator:
            self.live_orchestrator.stop_live_monitoring()
