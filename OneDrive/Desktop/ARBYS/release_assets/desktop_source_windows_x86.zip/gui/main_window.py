"""
Main GUI window for the arbitrage bot.
"""

import logging
import json
import os
import sys
from datetime import datetime
import requests

from PyQt6.QtCore import Qt, QThread, QTimer, pyqtSignal
from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QColor, QFont, QPixmap, QDesktopServices
from PyQt6.QtCore import QUrl
from PyQt6.QtWidgets import (
    QComboBox,
    QDoubleSpinBox,
    QDialog,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from config.settings import Config
from gui.tachometer_widget import TachometerWidget
from gui.theme_utils import (
    apply_accent_button,
    attach_accent_hover_effect,
    apply_label_glow,
    load_theme_stylesheet,
    polish_widget,
    load_app_icon,
    branding_paths,
)
from src.account_health import AccountHealthManager
from src.arbitrage import ArbitrageDetector, ArbitrageOpportunity
from src.stake_calculator import StakeCalculator
from src.utils import format_currency

logger = logging.getLogger(__name__)

# Mapping from provider names to website URLs for external reference
PROVIDER_URL_MAP = {
    # Common canonical keys
    "sofascore_scraper": "https://www.sofascore.com/",
    "the_odds_api": "https://the-odds-api.com/",
    "api_sports": "https://api-sports.io/",
    "sportradar": "https://sportradar.com/",
    # Human-readable names
    "SofaScore Scraper": "https://www.sofascore.com/",
    "The Odds API": "https://the-odds-api.com/",
    "API-SPORTS": "https://api-sports.io/",
    "Sportradar": "https://sportradar.com/",
    # Common alias variants
    "SofaScore": "https://www.sofascore.com/",
    "SofaScore API": "https://www.sofascore.com/",
    "SofaScore Scraper (free)": "https://www.sofascore.com/",
    "OddsAPI": "https://the-odds-api.com/",
    "TheOddsAPI": "https://the-odds-api.com/",
    "the-odds-api.com": "https://the-odds-api.com/",
    "API Sports": "https://api-sports.io/",
    "APISports": "https://api-sports.io/",
    "API SPORTS": "https://api-sports.io/",
    "Sportradar US": "https://sportradar.com/",
    "Sportradar Global": "https://sportradar.com/",
}


class OddsUpdateThread(QThread):
    """Thread for fetching odds data without blocking UI."""

    odds_updated = pyqtSignal(list)
    error_occurred = pyqtSignal(str)

    def __init__(self, data_fetcher, sport="soccer"):
        super().__init__()
        self.data_fetcher = data_fetcher
        self.sport = sport
        self.running = True

    def run(self):
        """Fetch odds data."""
        try:
            if not self.data_fetcher:
                if self.running:
                    self.error_occurred.emit(
                        "No data source configured. Please configure API providers in Settings."
                    )
                return
            events = self.data_fetcher.fetch_odds_sync(sport=self.sport)
            if self.running:
                self.odds_updated.emit(events)
        except Exception as e:
            if self.running:
                self.error_occurred.emit(str(e))

    def stop(self):
        """Stop the thread."""
        self.running = False


class ArbitrageBotGUI(QMainWindow):
    """Main GUI window for the arbitrage bot."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Redline Arbitrage - Profit at the limit")

        # Center window on screen
        self._center_on_screen()
        self.resize(1400, 900)

        # Apply application icon from branding suite (taskbar/window icon)
        try:
            app_icon = load_app_icon()
            if app_icon:
                self.setWindowIcon(app_icon)
        except Exception as e:
            logger.warning(f"Failed to apply window icon: {e}")

        # Initialize components
        self.account_health_manager = AccountHealthManager()
        self.arbitrage_detector = ArbitrageDetector(
            min_profit_percentage=Config.MIN_PROFIT_PERCENTAGE,
            account_health_manager=self.account_health_manager,
        )
        self.stake_calculator = StakeCalculator(
            round_stakes=Config.ROUND_STAKES,
            max_variation_percent=Config.MAX_BET_VARIATION_PERCENT,
            account_health_manager=self.account_health_manager,
            min_stake_threshold=10.0,
        )

        # Time-delay tracking
        self.bet_delay_timer = QTimer()
        self.bet_delay_seconds = 0
        self.current_bet_index = 0

        # Initialize multi-API orchestrator
        self.orchestrator = None
        self.data_fetcher = None
        self.last_primary_provider = None
        self.initialize_data_fetcher()

        self.selected_arbitrage = None
        self.current_stake_distribution = None
        self.current_arbitrages = []

        # Thread management: disable in test mode for stability
        self.update_thread = None
        # Do not gate updates on wizard suppression; production skip should still load data
        self._enable_update_thread = not Config.TEST_MODE

        # Suppress wizard in test mode
        self.suppress_wizard = Config.TEST_MODE or os.getenv("ARBYS_SUPPRESS_WIZARD") == "1"

        # Setup UI
        self.init_ui()

        # Setup update timer
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.fetch_odds)
        if self._enable_update_thread:
            self.update_timer.start(Config.UPDATE_INTERVAL * 1000)

        # Setup delay timer
        self.bet_delay_timer.timeout.connect(self.update_delay_countdown)
        self.bet_delay_timer.start(1000)  # Update every second

        # Setup provider health check timer
        self.provider_health_timer = QTimer()
        self.provider_health_timer.timeout.connect(self.update_provider_status)
        self.provider_health_timer.start(60000)  # Check every 60 seconds

        # Initial provider status update
        self.update_provider_status()

        # Setup backend health check timer (Flask API server)
        self.backend_health_timer = QTimer()
        self.backend_health_timer.timeout.connect(self.update_backend_health)
        self.backend_health_timer.start(60000)  # Check every 60 seconds

        # Initial backend health update
        self.update_backend_health()

        # For scanner/planner/calculator mode, allow loading without API configuration
        # Always perform an initial fetch when a data source is available,
        # regardless of wizard suppression state, so the dashboard populates.
        if self.data_fetcher:
            self.fetch_odds()
        else:
            # No modal welcome or splash — just inform via status bar
            try:
                self.statusBar().showMessage(
                    "No data providers configured. Open Settings → Configure API Providers to get started."
                )
            except Exception:
                pass

    def show_setup_wizard(self):
        """Setup Wizard deprecated: redirect to Provider Manager."""
        try:
            QMessageBox.information(
                self,
                "Setup Wizard Removed",
                "The Setup Wizard has been removed. Please use Settings → Configure API Providers.",
            )
        except Exception:
            pass
        return self.show_provider_manager()

    def open_setup_wizard(self):
        """Alias for show_setup_wizard() for compatibility with onboarding system."""
        self.show_setup_wizard()

    def show_provider_manager(self):
        """Open the API Provider Management dialog (production-friendly settings)."""
        try:
            from gui.api_provider_dialog import APIProviderDialog
            dlg = APIProviderDialog(self)
            dlg.exec()
            # Reinitialize data fetcher in case providers changed
            self.initialize_data_fetcher()
            if self.data_fetcher:
                self.fetch_odds()
        except Exception as e:
            logger.error(f"Error opening provider manager: {e}")
            QMessageBox.warning(
                self,
                "Error",
                f"Failed to open provider manager:\n{str(e)}",
            )

    def show_simplified_welcome(self):
        """Show a simplified welcome message for scanner/planner/calculator mode."""
        from PyQt6.QtWidgets import QMessageBox

        QMessageBox.information(
            self,
            "Welcome to Redline Arbitrage",
            "Welcome to Redline Arbitrage - Your Arbitrage Scanner and Calculator!\n\n"
            "This application helps you:\n"
            "• Scan for arbitrage opportunities across sportsbooks\n"
            "• Calculate optimal stake distributions\n"
            "• Plan betting scenarios with guaranteed profit\n\n"
            "To get started:\n"
            "1. Configure API providers in Settings → Configure API Providers\n"
            "2. Click 'Refresh Now' to scan for opportunities\n"
            "3. Select opportunities and use the stake calculator\n\n"
            "The calculator works with any selected arbitrage opportunity.",
        )

    def init_ui(self):
        """Initialize the user interface."""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QVBoxLayout(central_widget)

        # Header
        header = self.create_header()
        main_layout.addWidget(header)

        # Create splitter for main content
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left panel - Controls and arbitrage list
        left_panel = self.create_left_panel()
        splitter.addWidget(left_panel)

        # Middle panel - Stake calculator
        middle_panel = self.create_right_panel()
        splitter.addWidget(middle_panel)

        # Remove Account Health panel per user request (Manage Accounts feature removed)
        # Previously a right panel displayed account health and a Manage Accounts dialog.
        # We now use only two panels: opportunities (left) and calculator (middle).

        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)

        main_layout.addWidget(splitter)

        # Provider status panel (footer)
        provider_status_panel = self.create_provider_status_panel()
        main_layout.addWidget(provider_status_panel)

        # Status bar
        self.statusBar().showMessage("Ready")

        # Create menu bar
        self.create_menu_bar()

        # Apply theme properties (accent buttons, cards, etc.)
        self.apply_theme_styles()

    def create_header(self) -> QWidget:
        """Create header section."""
        header = QGroupBox("Redline Arbitrage Control Panel")
        # Keep reference for dynamic logo scaling
        self.header_group = header
        layout = QHBoxLayout()

        # Branding logo (horizontal) on the left side when available
        try:
            paths = branding_paths()
            logo_png = None
            logo_svg = None
            if paths:
                logo_png = paths.get("logo_horizontal_png")
                logo_svg = paths.get("logo_horizontal_svg")

            # Determine if HiDPI/retina is active to prefer SVG for crispness
            is_hidpi = self._is_hidpi()

            if is_hidpi and logo_svg and os.path.isfile(logo_svg):
                try:
                    from PyQt6.QtSvgWidgets import QSvgWidget

                    self.header_logo_svg = QSvgWidget(logo_svg)
                    self.header_logo_is_svg = True
                    # Initial height tuned for HiDPI (will be adjusted dynamically)
                    self.header_logo_svg.setFixedHeight(40)
                    layout.addWidget(self.header_logo_svg)
                    layout.addSpacing(10)
                except Exception as svg_e:
                    logger.debug(f"SVG logo preferred but unavailable: {svg_e}")
                    # Fallback to PNG below
                    is_hidpi = False

            if not getattr(self, "header_logo_is_svg", False) and logo_png and os.path.isfile(logo_png):
                self.header_logo_label = QLabel()
                pix = QPixmap(logo_png)
                if not pix.isNull():
                    # Store original pixmap for dynamic scaling
                    self.header_logo_pixmap = pix
                    self.header_logo_is_svg = False
                    # Initial scale
                    self._scale_header_logo()
                    self.header_logo_label.setToolTip("Redline Arbitrage")
                    layout.addWidget(self.header_logo_label)
                    layout.addSpacing(10)
        except Exception as e:
            logger.debug(f"Branding logo not applied to header: {e}")

        # Sport selector
        layout.addWidget(QLabel("Sport:"))
        self.sport_combo = QComboBox()
        self.sport_combo.addItems(["soccer", "basketball", "baseball", "hockey", "tennis"])
        layout.addWidget(self.sport_combo)

        layout.addSpacing(20)

        # Control buttons
        self.refresh_btn = QPushButton("Refresh Now")
        self.refresh_btn.clicked.connect(self.handle_refresh_click)
        layout.addWidget(self.refresh_btn)

        self.pause_btn = QPushButton("Pause Updates")
        self.pause_btn.clicked.connect(self.toggle_updates)
        layout.addWidget(self.pause_btn)

        # Manage Accounts removed per user request

        # Open provider manager directly (Setup Wizard deprecated)
        self.config_btn = QPushButton("⚙️ Providers")
        self.config_btn.clicked.connect(self.show_provider_manager)
        layout.addWidget(self.config_btn)

        layout.addStretch()

        # Status indicator
        self.status_label = QLabel("● Active")
        self.status_label.setProperty("status", "active")
        self.status_label.setStyleSheet("font-weight: bold;")

        # Provider status will be shown in footer panel
        layout.addWidget(self.status_label)

        # --- Windows-style window controls (Minimize / Maximize / Close) ---
        # Provide in-app title bar controls to match Windows UX
        controls_container = QWidget()
        controls_layout = QHBoxLayout(controls_container)
        controls_layout.setContentsMargins(0, 0, 0, 0)
        controls_layout.setSpacing(6)

        self.btn_minimize = QPushButton("–")
        self.btn_minimize.setFixedSize(28, 24)
        self.btn_minimize.setToolTip("Minimize")
        self.btn_minimize.clicked.connect(self.showMinimized)
        self.btn_minimize.setStyleSheet(
            """
            QPushButton {
                background-color: #1C1D22;
                border: 1px solid #2A2C31;
                border-radius: 4px;
                color: #E6E6E6;
                font-size: 12pt;
                padding: 0;
            }
            QPushButton:hover { background-color: #2A2C31; }
            QPushButton:pressed { background-color: #16171A; }
            """
        )
        controls_layout.addWidget(self.btn_minimize)

        self.btn_maximize = QPushButton("▢")
        self.btn_maximize.setFixedSize(28, 24)
        self.btn_maximize.setToolTip("Maximize / Restore")
        self.btn_maximize.clicked.connect(self._toggle_max_restore)
        self.btn_maximize.setStyleSheet(
            """
            QPushButton {
                background-color: #1C1D22;
                border: 1px solid #2A2C31;
                border-radius: 4px;
                color: #E6E6E6;
                font-size: 11pt;
                padding: 0;
            }
            QPushButton:hover { background-color: #2A2C31; }
            QPushButton:pressed { background-color: #16171A; }
            """
        )
        controls_layout.addWidget(self.btn_maximize)

        self.btn_close = QPushButton("✕")
        self.btn_close.setFixedSize(28, 24)
        self.btn_close.setToolTip("Close")
        self.btn_close.clicked.connect(self.close)
        self.btn_close.setStyleSheet(
            """
            QPushButton {
                background-color: #D00000;
                border: 1px solid #FF0033;
                border-radius: 4px;
                color: #FFFFFF;
                font-weight: bold;
                font-size: 11pt;
                padding: 0;
            }
            QPushButton:hover { background-color: #FF0033; }
            QPushButton:pressed { background-color: #B00000; }
            """
        )
        controls_layout.addWidget(self.btn_close)

        layout.addWidget(controls_container)

        header.setLayout(layout)
        return header

    def create_left_panel(self) -> QWidget:
        """Create left panel with arbitrage opportunities table."""
        panel = QWidget()
        layout = QVBoxLayout(panel)

        # Table for arbitrage opportunities
        table_label = QLabel("Arbitrage Opportunities")
        table_label.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        layout.addWidget(table_label)

        self.arbitrage_table = QTableWidget()
        self.arbitrage_table.setColumnCount(7)
        self.arbitrage_table.setHorizontalHeaderLabels(
            ["Event", "Profit %", "Outcomes", "Bookmakers", "Source", "Time", "Action"]
        )
        self.arbitrage_table.horizontalHeader().setStretchLastSection(True)
        self.arbitrage_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.arbitrage_table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.arbitrage_table.cellClicked.connect(self.on_arbitrage_selected)
        layout.addWidget(self.arbitrage_table)

        # Log area
        log_label = QLabel("Activity Log")
        log_label.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        layout.addWidget(log_label)

        self.log_text = QTextEdit()
        self.log_text.setMaximumHeight(150)
        self.log_text.setReadOnly(True)
        layout.addWidget(self.log_text)

        return panel

    def create_right_panel(self) -> QWidget:
        """Create right panel with stake calculator."""
        panel = QWidget()
        layout = QVBoxLayout(panel)

        calc_group = QGroupBox("Stake Calculator")
        calc_layout = QVBoxLayout()

        # Selected arbitrage info (card style)
        self.selected_arb_label = QLabel("Select an arbitrage opportunity")
        self.selected_arb_label.setWordWrap(True)
        self.selected_arb_label.setProperty("card", True)
        calc_layout.addWidget(self.selected_arb_label)

        calc_layout.addSpacing(10)

        # Stake input
        stake_layout = QHBoxLayout()
        stake_layout.addWidget(QLabel("Total Stake:"))
        self.stake_input = QDoubleSpinBox()
        self.stake_input.setRange(1.0, Config.MAX_STAKE)
        self.stake_input.setValue(Config.DEFAULT_STAKE)
        self.stake_input.setPrefix("$ ")
        self.stake_input.setDecimals(2)
        self.stake_input.valueChanged.connect(self.calculate_stakes)
        stake_layout.addWidget(self.stake_input)
        calc_layout.addLayout(stake_layout)

        calc_layout.addSpacing(10)

        # Calculate button
        self.calc_btn = QPushButton("Calculate Stakes")
        self.calc_btn.clicked.connect(self.calculate_stakes)
        calc_layout.addWidget(self.calc_btn)

        # Log bet button
        self.log_bet_btn = QPushButton("Log Bet as Placed")
        self.log_bet_btn.clicked.connect(self.log_bet_placed)
        self.log_bet_btn.setEnabled(False)
        calc_layout.addWidget(self.log_bet_btn)

        calc_layout.addSpacing(10)

        # Results table
        results_label = QLabel("Stake Distribution")
        results_label.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        calc_layout.addWidget(results_label)

        self.stake_table = QTableWidget()
        self.stake_table.setColumnCount(4)
        self.stake_table.setHorizontalHeaderLabels(["Outcome", "Bookmaker", "Stake", "Return"])
        self.stake_table.horizontalHeader().setStretchLastSection(True)
        self.stake_table.setMaximumHeight(200)
        calc_layout.addWidget(self.stake_table)

        calc_layout.addSpacing(10)

        # Summary (card style with success indicator)
        self.summary_label = QLabel("")
        self.summary_label.setProperty("card", True)
        self.summary_label.setProperty("status", "success")
        calc_layout.addWidget(self.summary_label)

        # Warnings/Risk display (card style)
        self.warnings_label = QLabel("")
        self.warnings_label.setWordWrap(True)
        self.warnings_label.setProperty("card", True)
        self.warnings_label.setMaximumHeight(100)
        calc_layout.addWidget(self.warnings_label)

        # Time-delay countdown (card style)
        self.delay_label = QLabel("")
        self.delay_label.setProperty("card", True)
        self.delay_label.setMaximumHeight(60)
        calc_layout.addWidget(self.delay_label)

        calc_group.setLayout(calc_layout)
        layout.addWidget(calc_group)

        layout.addStretch()

        return panel

    # Account Health panel removed

    # refresh_account_health removed

    # show_account_manager removed

    def set_update_thread_enabled(self, enabled: bool):
        """Enable or disable update thread (for testing)."""
        self._enable_update_thread = enabled
        if not enabled and self.update_thread:
            if self.update_thread.isRunning():
                self.update_thread.stop()
                self.update_thread.quit()
                self.update_thread.wait(1000)  # Wait max 1 second
            self.update_thread = None

    def closeEvent(self, event):  # pragma: no cover
        """Handle window close event - cleanup threads and timers."""
        if self._enable_update_thread and self.update_thread and self.update_thread.isRunning():
            self.update_thread.stop()
            self.update_thread.quit()
            self.update_thread.wait(1000)
        if hasattr(self, "update_timer"):
            self.update_timer.stop()
        if hasattr(self, "provider_health_timer"):
            self.provider_health_timer.stop()
        super().closeEvent(event)

    def fetch_odds(self):
        """Fetch odds data and update arbitrage opportunities."""
        if not self._enable_update_thread:
            # In test mode or when disabled, fetch synchronously
            if not self.data_fetcher:
                return
            try:
                events = self.data_fetcher.fetch_odds(self.sport_combo.currentText())
                self.on_odds_updated(events if events else [])
            except Exception as e:
                self.on_error(str(e))
            return

        if self.update_thread and self.update_thread.isRunning():
            return

        self.statusBar().showMessage("Fetching odds...")
        self.log_message("Fetching latest odds data...")

        if self.data_fetcher:
            self.update_thread = OddsUpdateThread(self.data_fetcher, self.sport_combo.currentText())
            self.update_thread.odds_updated.connect(self.on_odds_updated)
            self.update_thread.error_occurred.connect(self.on_error)
            self.update_thread.start()

    def on_odds_updated(self, events: list):
        """Handle updated odds data."""
        try:
            # If no events, do not generate synthetic data; honor real-provider-only policy
            if not events or len(events) == 0:
                self.statusBar().showMessage(
                    "No arbitrage opportunities found - configure API providers"
                )
                self.log_message("No events available from configured API providers")
                self.current_arbitrages = []
                self.update_arbitrage_table()
                return

            # Find arbitrage opportunities
            arbitrages = self.arbitrage_detector.find_best_arbitrages(events)

            # Do not augment with synthetic events; only real opportunities are shown

            self.current_arbitrages = arbitrages

            # Update table
            self.update_arbitrage_table()

            # Check for high-profit alerts
            for arb in arbitrages:
                if arb.profit_percentage >= Config.PROFIT_THRESHOLD_ALERT:
                    self.alert_high_profit(arb)

            self.statusBar().showMessage(
                f"Found {len(arbitrages)} arbitrage opportunities"
            )
            self.log_message(f"Found {len(arbitrages)} arbitrage opportunities")

        except Exception as e:
            logger.error(f"Error processing odds: {str(e)}")
            self.on_error(str(e))

    def on_error(self, error_msg: str):
        """Handle errors."""
        self.statusBar().showMessage(f"Error: {error_msg}")
        self.log_message(f"ERROR: {error_msg}")
        QMessageBox.warning(self, "Error", f"Failed to fetch odds:\n{error_msg}")

    def toggle_synthetic_opportunities(self, enabled: bool):
        """Persist user preference for synthetic opportunities (opt-in).

        Enforcement: If REAL_DATA_ONLY policy is enabled, synthetic generation is disallowed.
        """
        # Enforce REAL_DATA_ONLY policy before attempting to save
        try:
            if Config.get_real_data_only() and enabled:
                Config.save_synthesize_opportunities(False)
                # If a menu action is available, force it off
                if hasattr(self, "synth_action") and self.synth_action is not None:
                    try:
                        self.synth_action.setChecked(False)
                    except Exception:
                        pass
                self.log_message("Synthetic opportunities prevented by REAL_DATA_ONLY policy")
                QMessageBox.information(
                    self,
                    "Policy Enforcement",
                    "Real-data-only policy is enabled. Synthetic opportunities cannot be turned on.",
                )
                # Refresh to reflect changes immediately
                try:
                    self.fetch_odds()
                except Exception:
                    pass
                return
        except Exception:
            # If policy check fails, continue with normal save flow
            pass
        try:
            Config.save_synthesize_opportunities(bool(enabled))
            state = "enabled" if enabled else "disabled"
            self.log_message(f"Synthetic opportunities {state} via Settings")
            QMessageBox.information(
                self,
                "Settings Updated",
                f"Synthetic opportunities have been {state}.",
            )
            # Optionally refresh to reflect changes immediately
            self.fetch_odds()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to save setting: {str(e)}")

    def update_arbitrage_table(self):
        """Update the arbitrage opportunities table."""
        self.arbitrage_table.setRowCount(len(self.current_arbitrages))

        for row, arb in enumerate(self.current_arbitrages):
            # Event name
            self.arbitrage_table.setItem(row, 0, QTableWidgetItem(arb.event_name))

            # Profit percentage (color-coded with theme colors)
            profit_item = QTableWidgetItem(f"{arb.profit_percentage:.2f}%")
            if arb.profit_percentage >= 5.0:
                profit_item.setForeground(QColor(76, 175, 80))  # Theme green
            elif arb.profit_percentage >= 2.0:
                profit_item.setForeground(QColor(255, 152, 0))  # Theme orange
            self.arbitrage_table.setItem(row, 1, profit_item)

            # Outcomes
            outcomes_str = ", ".join([o["outcome_name"] for o in arb.outcomes])
            self.arbitrage_table.setItem(row, 2, QTableWidgetItem(outcomes_str))

            # Bookmakers
            bookmakers_str = ", ".join(arb.bookmakers)
            self.arbitrage_table.setItem(row, 3, QTableWidgetItem(bookmakers_str))

            # Source providers (clickable to validate raw data)
            source_widget = QWidget()
            source_layout = QHBoxLayout(source_widget)
            source_layout.setContentsMargins(0, 0, 0, 0)
            source_layout.setSpacing(4)
            if getattr(arb, "source_apis", None):
                for src in arb.source_apis:
                    btn = QPushButton(src)
                    btn.setToolTip(f"Validate raw data from {src}")
                    btn.setMaximumWidth(140)
                    # Bind click to show raw data dialog for this provider
                    btn.clicked.connect(lambda checked=False, a=arb, p=src: self.show_raw_data_dialog(a, p))
                    source_layout.addWidget(btn)
            else:
                # No source info; show N/A
                source_layout.addWidget(QLabel("N/A"))
            self.arbitrage_table.setCellWidget(row, 4, source_widget)

            # Time (simplified)
            time_str = (
                arb.timestamp.split("T")[1].split(".")[0] if "T" in arb.timestamp else arb.timestamp
            )
            self.arbitrage_table.setItem(row, 5, QTableWidgetItem(time_str))

            # Action button
            action_btn = QPushButton("Select")
            action_btn.clicked.connect(lambda *, r=row: self.select_arbitrage(r))
            apply_accent_button(action_btn)  # Apply accent styling
            self.arbitrage_table.setCellWidget(row, 6, action_btn)

            # Display risk level (color code entire row)
            if hasattr(arb, "risk_level"):
                if arb.risk_level == "High":
                    for col in range(7):
                        item = self.arbitrage_table.item(row, col)
                        if item:
                            item.setForeground(QColor(200, 0, 0))
                        else:
                            # For widgets, we can't change color easily
                            pass
                elif arb.risk_level == "Medium":
                    for col in range(7):
                        item = self.arbitrage_table.item(row, col)
                        if item:
                            item.setForeground(QColor(255, 140, 0))

        self.arbitrage_table.resizeColumnsToContents()

    def on_arbitrage_selected(self, row: int, col: int):
        """Handle arbitrage selection from table."""
        self.select_arbitrage(row)

    def select_arbitrage(self, row: int):
        """Select an arbitrage opportunity for stake calculation."""
        if hasattr(self, "current_arbitrages") and 0 <= row < len(self.current_arbitrages):
            self.selected_arbitrage = self.current_arbitrages[row]
            self.update_selected_arbitrage_display()
            self.calculate_stakes()

    def update_selected_arbitrage_display(self):
        """Update the display for selected arbitrage."""
        if not hasattr(self, "selected_arbitrage"):
            return

        arb = self.selected_arbitrage
        info_text = f"<b>{arb.event_name}</b><br>"
        info_text += f"Profit: <span style='color: green;'>{arb.profit_percentage:.2f}%</span><br>"
        info_text += f"Outcomes: {', '.join([o['outcome_name'] for o in arb.outcomes])}<br>"
        info_text += f"Bookmakers: {', '.join(arb.bookmakers)}"
        if getattr(arb, "source_apis", None):
            info_text += f"<br>Sources: {', '.join(arb.source_apis)}"

        self.selected_arb_label.setText(info_text)

    def show_raw_data_dialog(self, arb: ArbitrageOpportunity, provider_name: str | None = None):
        """Show a dialog to validate raw JSON data from the source provider(s)."""
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Raw Data Validation - {arb.event_name}")
        layout = QVBoxLayout(dlg)

        # Provider selector if multiple sources
        providers = list(getattr(arb, "source_apis", []) or [])
        if provider_name and provider_name not in providers:
            providers = [provider_name] + providers

        selector = None
        if len(providers) > 1:
            selector = QComboBox(dlg)
            selector.addItems(providers)
            layout.addWidget(QLabel("Select provider:"))
            layout.addWidget(selector)

        # JSON viewer
        json_view = QTextEdit(dlg)
        json_view.setReadOnly(True)
        layout.addWidget(json_view)

        def update_json_view(current_provider: str):
            raw_map = getattr(arb, "source_raw", {}) or {}
            raw = raw_map.get(current_provider)
            if raw is None:
                json_view.setPlainText(f"No raw data available for provider: {current_provider}")
                return
            try:
                json_view.setPlainText(json.dumps(raw, indent=2))
            except Exception:
                json_view.setPlainText(str(raw))

        # Initialize view
        selected_provider = provider_name or (providers[0] if providers else "")
        update_json_view(selected_provider)
        if selector:
            selector.currentTextChanged.connect(update_json_view)

        # Buttons row
        btn_row = QHBoxLayout()
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dlg.accept)
        btn_row.addWidget(close_btn)

        # Open provider website button if known
        website_btn = QPushButton("Open Provider Website")
        def open_website():
            current = selected_provider
            if selector:
                current = selector.currentText()
            url = PROVIDER_URL_MAP.get(current)
            if url:
                QDesktopServices.openUrl(QUrl(url))
            else:
                QMessageBox.information(self, "Info", f"No website mapping for provider: {current}")
        website_btn.clicked.connect(open_website)
        btn_row.addWidget(website_btn)

        layout.addLayout(btn_row)
        dlg.resize(800, 600)
        dlg.exec()

    def calculate_stakes(self):
        """Calculate stake distribution for selected arbitrage."""
        if not hasattr(self, "selected_arbitrage"):
            self.summary_label.setText("Please select an arbitrage opportunity")
            return

        try:
            total_stake = self.stake_input.value()

            # Calculate stakes
            stake_dist = self.stake_calculator.calculate_stakes(
                self.selected_arbitrage, total_stake
            )

            # Update stake table
            self.stake_table.setRowCount(len(stake_dist.stakes))

            for row, stake_info in enumerate(stake_dist.stakes):
                self.stake_table.setItem(row, 0, QTableWidgetItem(stake_info["outcome_name"]))
                self.stake_table.setItem(row, 1, QTableWidgetItem(stake_info["bookmaker"]))
                self.stake_table.setItem(
                    row, 2, QTableWidgetItem(format_currency(stake_info["stake"]))
                )
                self.stake_table.setItem(
                    row, 3, QTableWidgetItem(format_currency(stake_info["return"]))
                )

            self.stake_table.resizeColumnsToContents()

            # Store stake distribution for logging
            self.current_stake_distribution = stake_dist

            # Update summary
            summary_text = (
                f"<b>Guaranteed Profit:</b> {format_currency(stake_dist.guaranteed_profit)}<br>"
            )
            summary_text += f"<b>Total Return:</b> {format_currency(stake_dist.total_return)}<br>"
            summary_text += f"<b>Profit %:</b> {stake_dist.profit_percentage:.2f}%"
            self.summary_label.setText(summary_text)

            # Display warnings
            warnings_text = ""
            if stake_dist.warnings:
                warnings_text = "<b>⚠️ Warnings:</b><br>"
                warnings_text += "<br>".join([f"• {w}" for w in stake_dist.warnings])

            # Add risk warnings from arbitrage opportunity
            if (
                hasattr(self.selected_arbitrage, "risk_warnings")
                and self.selected_arbitrage.risk_warnings
            ):
                if warnings_text:
                    warnings_text += "<br>"
                warnings_text += "<b>⚠️ Risk Warnings:</b><br>"
                warnings_text += "<br>".join(
                    [f"• {w}" for w in self.selected_arbitrage.risk_warnings]
                )

            if warnings_text:
                self.warnings_label.setText(warnings_text)
                self.warnings_label.setProperty("status", "warning")
            else:
                self.warnings_label.setText("")
                self.warnings_label.setProperty("status", "")

            self._polish_widget(self.warnings_label)

            # Reset delay tracking
            self.current_bet_index = 0
            self.bet_delay_seconds = 0
            self.update_delay_display()

            # Enable log bet button
            self.log_bet_btn.setEnabled(True)

        except Exception as e:
            logger.error(f"Error calculating stakes: {str(e)}")
            QMessageBox.warning(self, "Error", f"Failed to calculate stakes:\n{str(e)}")
            self.log_bet_btn.setEnabled(False)

    def log_bet_placed(self):
        """Log arbitrage bet as placed."""
        if not self.selected_arbitrage or not self.current_stake_distribution:
            QMessageBox.warning(self, "Error", "No arbitrage selected or stakes not calculated")
            return

        try:
            # Log each bet for each bookmaker
            # Note: In arbitrage betting, only one outcome wins, but we log all bets
            # The profit is the guaranteed profit regardless of which outcome wins

            for stake_info in self.current_stake_distribution.stakes:
                bookmaker = stake_info["bookmaker"]
                outcome = stake_info["outcome_name"]
                stake = stake_info["stake"]
                odds = stake_info["odds"]

                # Profit if this outcome wins: return - total_stake
                # Since all outcomes have same return, profit is the same
                profit = self.current_stake_distribution.guaranteed_profit

                self.account_health_manager.log_arbitrage_bet(
                    bookmaker_name=bookmaker,
                    stake_amount=stake,
                    outcome=outcome,
                    odds=odds,
                    profit=profit,
                    event_name=self.selected_arbitrage.event_name,
                )

            # Refresh account health display
            # Account health UI removed; keep backend logging only

            QMessageBox.information(
                self,
                "Bet Logged",
                f"Successfully logged arbitrage bet for {self.selected_arbitrage.event_name}\n"
                f"Profit: {format_currency(self.current_stake_distribution.guaranteed_profit)}",
            )

            self.log_message(
                f"Logged arbitrage bet: {self.selected_arbitrage.event_name} - "
                f"{format_currency(self.current_stake_distribution.guaranteed_profit)} profit"
            )

            # Advance to next bet delay
            self.current_bet_index += 1
            self.bet_delay_seconds = 0
            self.update_delay_display()

            # Disable button until delay expires
            if self.current_bet_index < len(self.current_stake_distribution.stakes):
                self.log_bet_btn.setEnabled(False)
            else:
                # All bets logged
                self.log_bet_btn.setEnabled(False)
                self.current_stake_distribution = None

        except Exception as e:
            logger.error(f"Error logging bet: {str(e)}")
            QMessageBox.warning(self, "Error", f"Failed to log bet:\n{str(e)}")

    def alert_high_profit(self, arb: ArbitrageOpportunity):
        """Alert user about high-profit arbitrage opportunity."""
        self.log_message(
            f"🚨 HIGH PROFIT ALERT: {arb.profit_percentage:.2f}% profit on {arb.event_name}"
        )

        # Sound alerts have been disabled globally per user request.
        # Previously, a cross-platform beep was played here when
        # Config.ENABLE_SOUND_ALERTS was True. To permanently remove
        # notification sounds, we omit any audio triggers.
        # If future re-enablement is desired, consider routing through
        # a dedicated AudioManager with user settings.

    def toggle_updates(self):
        """Toggle automatic updates."""
        if self.update_timer.isActive():
            self.update_timer.stop()
            self.pause_btn.setText("Resume Updates")
            self.status_label.setText("● Paused")
            self.status_label.setProperty("status", "paused")
            self._polish_widget(self.status_label)
            self.log_message("Updates paused")
        else:
            self.update_timer.start(Config.UPDATE_INTERVAL * 1000)
            self.pause_btn.setText("Pause Updates")
            self.status_label.setText("● Active")
            self.status_label.setProperty("status", "active")
            self._polish_widget(self.status_label)
            self.log_message("Updates resumed")
            self.fetch_odds()

    def log_message(self, message: str):
        """Add message to log."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.append(f"[{timestamp}] {message}")

    def update_delay_display(self):
        """Update the delay countdown display."""
        if not hasattr(self, "current_stake_distribution") or not self.current_stake_distribution:
            self.delay_label.setText("")
            return

        num_bets = len(self.current_stake_distribution.stakes)

        if self.current_bet_index >= num_bets:
            self.delay_label.setText("✅ All bets can be placed")
            self.delay_label.setProperty("status", "success")
            self._polish_widget(self.delay_label)
            return

        if self.current_bet_index == 0:
            # First bet can be placed immediately
            self.delay_label.setText("✅ Ready to place Bet 1 of " + str(num_bets))
            self.delay_label.setProperty("status", "ready")
            self._polish_widget(self.delay_label)
        else:
            # Calculate recommended delay (15 seconds between bets)
            recommended_delay = 15
            remaining = recommended_delay - self.bet_delay_seconds

            if remaining <= 0:
                self.delay_label.setText(
                    f"✅ Ready to place Bet {self.current_bet_index + 1} of {num_bets}"
                )
                self.delay_label.setProperty("status", "ready")
                self.delay_label.setToolTip("Pit stop complete. Ready to place bet.")
            else:
                self.delay_label.setText(
                    f"⏳ Wait {remaining} seconds before placing Bet {self.current_bet_index + 1} of {num_bets}<br>"
                    f"<small>(Recommended delay: {recommended_delay}s between bets)</small>"
                )
                self.delay_label.setProperty("status", "waiting")
                self.delay_label.setToolTip(
                    f"PIT STOP: {remaining}s remaining\n"
                    f"Preventing simultaneous bet placement to maintain stealth.\n"
                    f"Next bet available in {remaining} seconds."
                )
            self._polish_widget(self.delay_label)

    def update_delay_countdown(self):
        """Update delay countdown timer."""
        if (
            hasattr(self, "current_stake_distribution")
            and self.current_stake_distribution
            and self.current_bet_index > 0
            and self.current_bet_index < len(self.current_stake_distribution.stakes)
        ):
            self.bet_delay_seconds += 1
            recommended_delay = 15
            if self.bet_delay_seconds >= recommended_delay:
                # Delay expired, enable button
                self.log_bet_btn.setEnabled(True)
            self.update_delay_display()

    def initialize_data_fetcher(self):
        """Initialize data fetcher with orchestrator or legacy single API."""
        # Lazy imports for startup optimization
        from src.api_providers.api_sports import APISportsProvider
        from src.api_providers.sofascore_scraper import SofaScoreScraperProvider
        from src.data_acquisition import OrchestratedDataFetcher
        from src.data_orchestrator import MultiAPIOrchestrator

        try:
            # Always try to create a data fetcher - even with free sources
            providers_config = Config.get_api_providers()

            # Create provider instances - prioritize free sources
            providers = []

            # Always add SofaScore scraper (free unlimited)
            providers.append(
                SofaScoreScraperProvider(
                    api_key="scraper",  # Not used, kept for interface compatibility
                    enabled=True,
                    priority=1,  # Highest priority for free source
                    cache_ttl=300,
                    max_requests_per_second=2.0,
                )
            )

            # Add configured paid providers if API keys are available
            if providers_config:
                for provider_config in providers_config:
                    if not provider_config.get("enabled", False):
                        continue

                    provider_type = provider_config.get("type", "sofascore_scraper")
                    api_key = provider_config.get("api_key", "")
                    priority = provider_config.get("priority", 999)

                    if provider_type == "api_sports" and api_key:
                        providers.append(
                            APISportsProvider(api_key=api_key, enabled=True, priority=priority)
                        )
                    elif provider_type == "the_odds_api" and api_key:
                        # The Odds API support
                        try:
                            from src.api_providers.the_odds_api import TheOddsAPIProvider
                            providers.append(
                                TheOddsAPIProvider(api_key=api_key, enabled=True, priority=priority)
                            )
                        except ImportError:
                            logger.warning("The Odds API provider not available")
                    elif provider_type == "sportradar" and api_key:
                        # Sportradar support
                        try:
                            from src.api_providers.sportradar import SportradarProvider
                            providers.append(
                                SportradarProvider(api_key=api_key, enabled=True, priority=priority)
                            )
                        except ImportError:
                            logger.warning("Sportradar provider not available")

            # Create orchestrator with free sources as fallback
            self.orchestrator = MultiAPIOrchestrator(
                providers=providers, failover_enabled=True, require_all_providers=False
            )

            # Wrap in backward-compatible interface
            self.data_fetcher = OrchestratedDataFetcher(self.orchestrator)
            logger.info(f"Initialized data fetcher with {len(providers)} provider(s) (free sources always available)")

            # Track primary provider
            if providers:
                self.last_primary_provider = providers[0].get_provider_name()

        except Exception as e:
            logger.error(f"Error initializing data fetcher: {e}")
            self.data_fetcher = None
            self.orchestrator = None
            QMessageBox.warning(
                None,
                "Data Source Warning",
                "Unable to initialize data sources. Please configure API providers in Settings.\n\n"
                "Go to: Settings → Configure API Providers",
            )

    def apply_theme_styles(self):  # pragma: no cover
        """Apply theme-specific properties (accent buttons, cards, etc.)."""
        # Mark important buttons as accent (red glow on hover)
        accent_buttons = [
            self.refresh_btn,
            self.calc_btn,
            self.log_bet_btn,
            self.config_btn,
        ]

        for btn in accent_buttons:
            if btn:
                # Ensure accent property for QSS styling
                apply_accent_button(btn)
                # Attach hover glow without relying on unsupported QSS properties
                attach_accent_hover_effect(btn)

        # Apply card properties and polish all widgets with card property
        for attr in [
            "selected_arb_label",
            "summary_label",
            "warnings_label",
            "delay_label",
        ]:
            if hasattr(self, attr):
                self._polish_widget(getattr(self, attr))
        self._polish_widget(self.status_label)

        # Apply glow effect to labels that declare glow="red"
        try:
            from PyQt6.QtWidgets import QLabel, QPushButton

            # Explicit known glow label
            if hasattr(self, "failover_alert_label") and self.failover_alert_label:
                if self.failover_alert_label.property("glow") == "red":
                    apply_label_glow(self.failover_alert_label, color_hex="#FF0033", alpha=0.85, blur_radius=14)

            # Global: attach hover glow to all accent buttons across the window
            for btn in self.findChildren(QPushButton):
                try:
                    if btn.property("accent") is True:
                        attach_accent_hover_effect(btn)
                except Exception:
                    # Best-effort; skip any problematic widgets
                    pass

            # Global: apply label glow to any other labels that use glow property
            for lbl in self.findChildren(QLabel):
                try:
                    glow = lbl.property("glow")
                    if glow == "red":
                        apply_label_glow(lbl, color_hex="#FF0033", alpha=0.85, blur_radius=14)
                except Exception:
                    pass
        except Exception:
            # Avoid failing theming if PyQt classes can't be imported in certain contexts
            pass

    def _center_on_screen(self):
        """Center the window on the primary screen."""
        try:
            # Get the primary screen
            screen = QApplication.primaryScreen()
            if screen:
                screen_geometry = screen.geometry()
                # Calculate center position
                x = (screen_geometry.width() - 1400) // 2
                y = (screen_geometry.height() - 900) // 2
                # Ensure we don't go off-screen
                x = max(0, x)
                y = max(0, y)
                self.move(x, y)
        except Exception as e:
            logger.warning(f"Failed to center window on screen: {e}")
            # Fallback to default positioning
            self.move(100, 100)

    def _polish_widget(self, widget):
        """Helper to polish a widget to apply property-based styles."""
        polish_widget(widget)

    def create_provider_status_panel(self) -> QWidget:
        """Create provider status panel footer."""
        panel = QGroupBox("API Provider Status")
        panel.setMaximumHeight(120)
        layout = QVBoxLayout(panel)

        # Status container
        status_layout = QHBoxLayout()

        # Provider status container
        self.provider_status_container = QWidget()
        self.provider_status_container_layout = QHBoxLayout(self.provider_status_container)
        self.provider_status_container_layout.setContentsMargins(0, 0, 0, 0)
        status_layout.addWidget(self.provider_status_container)

        status_layout.addStretch()

        # Backend health indicator (Flask API server)
        self.backend_status_label = QLabel("Backend: Checking…")
        self.backend_status_label.setToolTip("Checking backend health")
        # Reuse provider_status property styling
        self.backend_status_label.setProperty("provider_status", "degraded")
        self.backend_status_label.setStyleSheet(
            "font-weight: bold; padding: 5px; border: 1px solid; border-radius: 3px; margin: 2px;"
        )
        status_layout.addWidget(self.backend_status_label)

        # Failover alert label
        self.failover_alert_label = QLabel("")
        self.failover_alert_label.setProperty("glow", "red")
        self.failover_alert_label.setStyleSheet("font-weight: bold;")
        self.failover_alert_label.setVisible(False)
        self._polish_widget(self.failover_alert_label)
        status_layout.addWidget(self.failover_alert_label)

        layout.addLayout(status_layout)

        # Info label (muted text style)
        info_label = QLabel("Provider health is checked every 60 seconds")
        info_label.setStyleSheet("font-size: 10px;")
        layout.addWidget(info_label)

        return panel

    def update_provider_status(self):  # pragma: no cover
        """Update provider status display."""
        if not self.orchestrator:
            # No orchestrator, show legacy status
            if hasattr(self, "provider_status_container"):
                # Clear existing labels
                for i in reversed(range(self.provider_status_container_layout.count())):
                    self.provider_status_container_layout.itemAt(i).widget().setParent(None)

                # No orchestrator - show error
                label = QLabel("● No Data Source Configured")
                label.setStyleSheet("color: red; font-weight: bold; padding: 5px;")
                self.provider_status_container_layout.addWidget(label)
            return

        # Get provider statuses
        provider_statuses = self.orchestrator.get_provider_status()

        # Clear existing labels
        if hasattr(self, "provider_status_container"):
            for i in reversed(range(self.provider_status_container_layout.count())):
                widget = self.provider_status_container_layout.itemAt(i).widget()
                if widget:
                    widget.setParent(None)

            # Detect current primary provider
            enabled_providers = [
                (name, health) for name, health in provider_statuses.items() if health.enabled
            ]

            if not enabled_providers:
                label = QLabel("● No Providers Enabled")
                label.setStyleSheet("color: red; font-weight: bold; padding: 5px;")
                self.provider_status_container_layout.addWidget(label)
                return

            # Sort by priority
            enabled_providers.sort(key=lambda x: x[1].priority)
            current_primary = enabled_providers[0][0]

            # Check for failover
            if self.last_primary_provider and current_primary != self.last_primary_provider:
                self.show_failover_alert(self.last_primary_provider, current_primary)
                self.last_primary_provider = current_primary

            # Display status for each provider
            all_healthy = True
            any_degraded = False

            for provider_name, health in enabled_providers:
                status = health.status

                # Determine color
                if status == "healthy":
                    status_text = "●"
                elif status == "degraded":
                    status_text = "⚠"
                    any_degraded = True
                elif status == "down":
                    status_text = "✗"
                    all_healthy = False
                else:
                    status_text = "?"

                # Create status label
                display_name = provider_name.replace("_", " ").title()
                if provider_name == current_primary:
                    display_name += " (Primary)"

                label_text = f"{status_text} {display_name}"
                if health.last_success:
                    # Add success count
                    total = health.success_count + health.error_count
                    if total > 0:
                        success_rate = (health.success_count / total) * 100
                        label_text += f" ({success_rate:.0f}%)"

                label = QLabel(label_text)
                # Use theme colors instead of hardcoded colors
                label.setProperty("provider_status", status)
                label.setStyleSheet(
                    "font-weight: bold; padding: 5px; border: 1px solid; border-radius: 3px; margin: 2px;"
                )
                self.provider_status_container_layout.addWidget(label)

            # Update overall status
            if not all_healthy:
                self.statusBar().showMessage("Warning: Some API providers are down", 5000)
            elif any_degraded:
                self.statusBar().showMessage("Notice: Some API providers are degraded", 5000)

    def show_failover_alert(self, old_provider: str, new_provider: str):
        """Show failover alert message."""
        old_name = old_provider.replace("_", " ").title()
        new_name = new_provider.replace("_", " ").title()

        alert_text = f"⚠️ FAILOVER: {old_name} → {new_name}"
        self.failover_alert_label.setText(alert_text)
        self.failover_alert_label.setVisible(True)

        # Hide after 10 seconds
        QTimer.singleShot(10000, lambda: self.failover_alert_label.setVisible(False))

        # Log to status bar
        self.statusBar().showMessage(
            f"Failover detected: Switched from {old_name} to {new_name}", 10000
        )

        logger.warning(f"Provider failover: {old_provider} → {new_provider}")

    def update_backend_health(self):  # pragma: no cover
        """Check Flask backend health (/api/health) and update label."""
        try:
            origin = os.getenv("ARBYS_BACKEND_URL", "http://localhost:5000")
            url = f"{origin}/api/health"
            resp = requests.get(url, timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                status_text = str(data.get("status", "Unknown"))
                version = str(data.get("version", "n/a"))
                ts = str(data.get("timestamp", ""))
                # Determine label status
                healthy = status_text.lower() == "healthy"
                human_time = ts
                try:
                    # Convert ISO timestamp to human relative if possible
                    dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                    now = datetime.now(dt.tzinfo) if dt.tzinfo else datetime.now()
                    diff = now - dt
                    mins = int(diff.total_seconds() // 60)
                    if mins < 60:
                        human_time = f"{mins}m ago"
                    else:
                        hours = mins // 60
                        human_time = f"{hours}h ago"
                except Exception:
                    pass

                self.backend_status_label.setText(
                    f"Backend: {'Healthy' if healthy else status_text}"
                )
                self.backend_status_label.setToolTip(f"Version {version} • Updated {human_time}")
                self.backend_status_label.setProperty("provider_status", "healthy" if healthy else "degraded")
                self._polish_widget(self.backend_status_label)
            else:
                # Non-200 is treated as down
                self.backend_status_label.setText("Backend: Unreachable")
                self.backend_status_label.setToolTip(f"HTTP {resp.status_code}")
                self.backend_status_label.setProperty("provider_status", "down")
                self._polish_widget(self.backend_status_label)
                self.statusBar().showMessage("Backend API unreachable", 5000)
        except Exception as e:
            self.backend_status_label.setText("Backend: Unreachable")
            self.backend_status_label.setToolTip(str(e))
            self.backend_status_label.setProperty("provider_status", "down")
            self._polish_widget(self.backend_status_label)
            logger.warning(f"Backend health check failed: {e}")

    def handle_refresh_click(self):
        """Trigger odds fetch and backend health update together."""
        try:
            self.fetch_odds()
        finally:
            # Always update backend health indicator
            self.update_backend_health()

    def create_menu_bar(self):
        """Create menu bar with Settings and Help menus."""
        menubar = self.menuBar()

        # Settings menu
        settings_menu = menubar.addMenu("Settings")

        branding_action = settings_menu.addAction("Branding...")
        branding_action.triggered.connect(self.open_branding_dialog)

        providers_action = settings_menu.addAction("Configure API Providers...")
        providers_action.triggered.connect(self.show_provider_manager)

        # Synthetic opportunities toggle (opt-in)
        self.synth_action = settings_menu.addAction("Enable Synthetic Opportunities (opt-in)")
        self.synth_action.setCheckable(True)
        try:
            self.synth_action.setChecked(Config.get_synthesize_opportunities())
        except Exception:
            self.synth_action.setChecked(False)
        self.synth_action.toggled.connect(self.toggle_synthetic_opportunities)

        # Help menu (tutorial/slideshow hidden universally)
        help_menu = menubar.addMenu("Help")
        help_menu.addSeparator()
        about_action = help_menu.addAction("About")
        about_action.triggered.connect(self.show_about)

    def open_branding_dialog(self):
        """Simple branding dialog to preview logo and open the branding folder."""
        from PyQt6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout

        dlg = QDialog(self)
        dlg.setWindowTitle("Branding")

        v = QVBoxLayout(dlg)
        logo_label = QLabel()
        logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        root = None
        social_root = None
        try:
            paths = branding_paths()
            if paths:
                root = paths.get("root")
                social_root = paths.get("social_root")
                # Prefer SVG if available
                svg = paths.get("logo_horizontal_svg")
                png = paths.get("logo_horizontal_png")
                if svg and os.path.isfile(svg):
                    try:
                        from PyQt6.QtSvgWidgets import QSvgWidget

                        svg_widget = QSvgWidget(svg)
                        svg_widget.setFixedHeight(120)
                        v.addWidget(svg_widget)
                    except Exception:
                        # Fallback to PNG render
                        if png and os.path.isfile(png):
                            pix = QPixmap(png)
                            if not pix.isNull():
                                logo_label.setPixmap(
                                    pix.scaledToWidth(
                                        380, Qt.TransformationMode.SmoothTransformation
                                    )
                                )
                elif png and os.path.isfile(png):
                    pix = QPixmap(png)
                    if not pix.isNull():
                        logo_label.setPixmap(
                            pix.scaledToWidth(380, Qt.TransformationMode.SmoothTransformation)
                        )
        except Exception as e:
            logger.debug(f"Branding dialog logo load failed: {e}")

        v.addWidget(logo_label)

        info = QLabel(
            "Customize the brand by editing palette.json, typography.json, and logos/icons in the branding suite."
        )
        info.setWordWrap(True)
        v.addWidget(info)

        # Buttons
        h = QHBoxLayout()
        open_btn = QPushButton("Open Branding Folder")
        apply_accent_button(open_btn)
        open_btn.clicked.connect(lambda: self._open_branding_folder(root))
        h.addWidget(open_btn)

        if social_root:
            social_btn = QPushButton("Open Social Kit Folder")
            apply_accent_button(social_btn)
            social_btn.clicked.connect(lambda: self._open_branding_folder(social_root))
            h.addWidget(social_btn)
        h.addStretch()
        v.addLayout(h)

        dlg.resize(520, 280)
        dlg.exec()

    def _open_branding_folder(self, path: str | None):
        if not path or not os.path.isdir(path):
            QMessageBox.information(
                self,
                "Branding",
                "Branding folder not found. Ensure the Redline_Arbitrage_Branding_Suite is bundled.",
            )
            return
        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        except Exception as e:
            logger.warning(f"Failed to open branding folder: {e}")

    def _get_screen_metrics(self) -> tuple[float, float]:
        """Return (devicePixelRatio, logicalDpi) for current screen."""
        try:
            screen = None
            if self.windowHandle():
                screen = self.windowHandle().screen()
            if screen is None:
                screen = QApplication.primaryScreen()
            dpr = float(getattr(screen, "devicePixelRatio", lambda: 1.0)()) if screen else 1.0
            dpi = float(getattr(screen, "logicalDotsPerInch", lambda: 96.0)()) if screen else 96.0
            return dpr, dpi
        except Exception:
            return 1.0, 96.0

    def _is_hidpi(self) -> bool:
        """Heuristic to determine if HiDPI/retina scaling is active."""
        dpr, dpi = self._get_screen_metrics()
        return dpr >= 1.5 or dpi >= 125.0

    def _scale_header_logo(self):
        """Scale the header logo to fit the header group height while maintaining aspect ratio and HiDPI crispness."""
        try:
            dpr, dpi = self._get_screen_metrics()
            is_hidpi = dpr >= 1.5 or dpi >= 125.0
            header_h = self.header_group.height() if hasattr(self, "header_group") else 36
            # Tunable thresholds
            if is_hidpi:
                min_h, max_h_cap = 32, 56
            else:
                min_h, max_h_cap = 24, 42
            target_h_css = max(min_h, min(max_h_cap, header_h - 12))

            if getattr(self, "header_logo_is_svg", False) and hasattr(self, "header_logo_svg"):
                # SVG: set widget height, vector scales crisply automatically
                self.header_logo_svg.setFixedHeight(int(target_h_css))
                return

            if hasattr(self, "header_logo_label") and hasattr(self, "header_logo_pixmap"):
                if self.header_logo_label and self.header_logo_pixmap and not self.header_logo_pixmap.isNull():
                    # For raster images, scale by CSS height multiplied by DPR for sharpness
                    target_device_px = int(target_h_css * max(1.0, dpr))
                    scaled = self.header_logo_pixmap.scaledToHeight(
                        target_device_px, Qt.TransformationMode.SmoothTransformation
                    )
                    # Set device pixel ratio if available for crisp display on HiDPI
                    try:
                        scaled.setDevicePixelRatio(max(1.0, dpr))
                    except Exception:
                        pass
                    self.header_logo_label.setPixmap(scaled)
                    self.header_logo_label.setFixedHeight(int(target_h_css))
        except Exception:
            # Non-critical
            pass

    def resizeEvent(self, event):
        """Handle window resize: rescale header logo dynamically."""
        try:
            self._scale_header_logo()
        except Exception:
            pass
        super().resizeEvent(event)

    def show_about(self):
        """Show an About dialog with branding logo and version information."""
        from PyQt6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout
        version = "Unknown"
        # Try to read version from pyproject.toml
        try:
            import tomllib
            project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            pyproj = os.path.join(project_root, "pyproject.toml")
            if os.path.isfile(pyproj):
                with open(pyproj, "rb") as f:
                    data = tomllib.load(f)
                    version = (
                        data.get("project", {}).get("version")
                        or data.get("tool", {}).get("poetry", {}).get("version")
                        or version
                    )
        except Exception:
            pass

        dlg = QDialog(self)
        dlg.setWindowTitle("About Redline Arbitrage")
        v = QVBoxLayout(dlg)

        # Logo
        logo_label = QLabel()
        logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        try:
            paths = branding_paths()
            if paths:
                # Prefer SVG when available
                svg = paths.get("logo_horizontal_svg")
                png = paths.get("logo_horizontal_png")
                if svg and os.path.isfile(svg):
                    try:
                        from PyQt6.QtSvgWidgets import QSvgWidget

                        svg_widget = QSvgWidget(svg)
                        svg_widget.setFixedHeight(140)
                        v.addWidget(svg_widget)
                    except Exception:
                        if png and os.path.isfile(png):
                            pix = QPixmap(png)
                            if not pix.isNull():
                                logo_label.setPixmap(
                                    pix.scaledToWidth(
                                        420, Qt.TransformationMode.SmoothTransformation
                                    )
                                )
                                v.addWidget(logo_label)
                elif png and os.path.isfile(png):
                    pix = QPixmap(png)
                    if not pix.isNull():
                        logo_label.setPixmap(
                            pix.scaledToWidth(420, Qt.TransformationMode.SmoothTransformation)
                        )
                        v.addWidget(logo_label)
        except Exception:
            pass

        info = QLabel(
            f"<b>Redline Arbitrage</b><br>Version: {version}<br><br>"
            "Redline Arbitrage — a multi-API arbitrage bot with responsive UI and theming."
        )
        info.setWordWrap(True)
        info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        v.addWidget(info)

        # Buttons
        h = QHBoxLayout()
        ok_btn = QPushButton("OK")
        apply_accent_button(ok_btn)
        ok_btn.clicked.connect(dlg.accept)
        h.addStretch()
        h.addWidget(ok_btn)
        h.addStretch()
        v.addLayout(h)

        dlg.resize(520, 300)
        dlg.exec()

    def run_tutorial(self):
        """Run the onboarding tutorial again."""
        try:
            from onboarding.first_run_manager import load_flags, save_flags
            from onboarding.tutorial_overlay import OnboardingTour

            # Reset tutorial completion flag
            flags = load_flags()
            flags["has_completed_tutorial"] = False
            save_flags(flags)

            # Prepare tutorial steps
            steps = []
            registry = self.get_widget_registry()

            # Step 1: Scan button
            if "btn_scan" in registry and registry["btn_scan"]:
                steps.append(
                    (
                        registry["btn_scan"],
                        "Scan for Opportunities",
                        "Click the 'Refresh Now' button to manually scan for arbitrage opportunities. "
                        "The bot automatically updates every 30 seconds, but you can force an immediate refresh.",
                    )
                )

            # Step 2: Opportunities table
            if "tbl_opportunities" in registry and registry["tbl_opportunities"]:
                steps.append(
                    (
                        registry["tbl_opportunities"],
                        "Opportunities Table",
                        "This table shows all available arbitrage opportunities. Select any row to see "
                        "stake calculations. Opportunities are sorted by profit percentage.",
                    )
                )

            # Step 3: Stake calculator
            if "panel_calc" in registry and registry["panel_calc"]:
                steps.append(
                    (
                        registry["panel_calc"],
                        "Stake Calculator",
                        "Enter your total stake amount and click 'Calculate Stakes' to see the optimal "
                        "distribution across all outcomes. The calculator ensures maximum guaranteed profit.",
                    )
                )

            # Step 4: Account health (optional)
            if "panel_health" in registry and registry["panel_health"]:
                steps.append(
                    (
                        registry["panel_health"],
                        "Account Health",
                        "Monitor your bookmaker account health and stealth scores. Green indicates healthy "
                        "accounts, while orange or red means increased risk. Keep stealth scores high to "
                        "minimize account closure risk.",
                    )
                )

            if steps:
                tour = OnboardingTour(steps, self)

                def on_tutorial_finished():
                    flags = load_flags()
                    flags["has_completed_tutorial"] = True
                    save_flags(flags)

                tour.finished.connect(on_tutorial_finished)
                tour.show()
            else:
                QMessageBox.information(
                    self,
                    "Tutorial",
                    "Tutorial steps are not available. Please ensure all UI components are initialized.",
                )
        except ImportError as e:
            logger.error(f"Could not import onboarding modules: {e}")
            QMessageBox.warning(
                self, "Error", "Onboarding system not available. Please restart the application."
            )
        except Exception as e:
            logger.error(f"Error running tutorial: {e}")
            QMessageBox.warning(self, "Error", f"Failed to run tutorial: {str(e)}")

    def get_widget_registry(self) -> dict:
        """
        Get widget registry for onboarding system.

        Returns:
            Dictionary mapping tooltip keys to widget instances:
            - btn_scan: Refresh button
            - tbl_opportunities: Arbitrage opportunities table
            - panel_calc: Stake calculator panel/widget
            - panel_health: Account health panel/widget
            - btn_providers: Setup/configuration button
            - badge_delay: Delay countdown label
            - stake_input: Stake input spinbox
        """
        registry = {}

        # Map tooltip keys to widget attributes
        if hasattr(self, "refresh_btn"):
            registry["btn_scan"] = self.refresh_btn

        if hasattr(self, "arbitrage_table"):
            registry["tbl_opportunities"] = self.arbitrage_table

        # Stake calculator panel - get the middle panel or the calc group
        if hasattr(self, "stake_input"):
            registry["stake_input"] = self.stake_input
            # Try to get the parent group or panel
            calc_widget = self.stake_input.parent()
            while calc_widget and not isinstance(calc_widget, QGroupBox):
                calc_widget = calc_widget.parent()
            if calc_widget:
                registry["panel_calc"] = calc_widget

        # Account health panel removed

        if hasattr(self, "config_btn"):
            registry["btn_providers"] = self.config_btn

        if hasattr(self, "delay_label"):
            registry["badge_delay"] = self.delay_label

        return registry

    def show_firstday_slideshow(self):
        """Show the first-day slideshow dialog."""
        try:
            from gui.ui_firstday_slideshow import FirstDaySlideshowDialog

            dialog = FirstDaySlideshowDialog(self)
            dialog.exec()
        except ImportError as e:
            logger.error(f"Could not import slideshow dialog: {e}")
            QMessageBox.warning(
                self,
                "Slideshow Unavailable",
                "The first-day slideshow requires PyQt6-WebEngine.\n\n"
                "Please install it with:\n"
                "  pip install PyQt6-WebEngine",
            )
        except Exception as e:
            logger.error(f"Error showing slideshow: {e}")
            QMessageBox.warning(self, "Error", f"Failed to open slideshow:\n{str(e)}")

    def _toggle_max_restore(self):
        """Toggle between maximized and normal window state."""
        try:
            if self.isMaximized():
                self.showNormal()
            else:
                self.showMaximized()
        except Exception as e:
            logger.warning(f"Maximize/restore toggle failed: {e}")




def main():
    """Main entry point for the GUI application."""
    from PyQt6.QtWidgets import QApplication

    app = QApplication(sys.argv)
    app.setStyle("Fusion")  # Modern look

    # Load carbon fiber + red theme
    project_root = os.path.dirname(os.path.dirname(__file__))
    stylesheet = load_theme_stylesheet(project_root)
    if stylesheet:
        app.setStyleSheet(stylesheet)
    else:
        logger.warning("Theme not loaded, using default Fusion style")

    window = ArbitrageBotGUI()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
