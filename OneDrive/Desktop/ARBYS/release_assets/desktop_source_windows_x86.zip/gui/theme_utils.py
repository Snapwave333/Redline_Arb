"""
Theme utility functions for consistent theme application across the GUI.

Adds Redline Arbitrage Branding integration:
- Locate branding suite (dev and packaged paths supported)
- Load palette/typography JSON
- Build app icon from branding icons
- Apply palette/typography to the loaded QSS dynamically
"""

import logging
import os
import sys
import json

from PyQt6.QtCore import QObject, QEvent
from PyQt6.QtGui import QColor, QIcon, QImage
from PyQt6.QtWidgets import QPushButton, QGraphicsDropShadowEffect

logger = logging.getLogger(__name__)


def load_theme_stylesheet(project_root: str = None) -> str:
    """
    Load the carbon fiber + red theme stylesheet.

    Args:
        project_root: Root directory of the project. If None, attempts to auto-detect.

    Returns:
        Stylesheet string, or empty string if theme not found.
    """
    if project_root is None:
        # Try to detect project root
        current_file = os.path.abspath(__file__)
        # Assuming we're in gui/theme_utils.py, go up one level to project root
        project_root = os.path.dirname(os.path.dirname(current_file))

    theme_path = os.path.join(project_root, "looks", "themes", "carbon_red.qss")

    if not os.path.exists(theme_path):
        logger.warning(f"Theme file not found at: {theme_path}")
        return ""

    try:
        with open(theme_path, encoding="utf-8") as f:
            stylesheet = f.read()

        # Replace relative SVG path with absolute path
        svg_path = os.path.join(project_root, "looks", "assets", "carbon_fiber_tile.svg")
        if os.path.exists(svg_path):
            svg_path = svg_path.replace("\\", "/")
            stylesheet = stylesheet.replace(
                "url(../assets/carbon_fiber_tile.svg)", f"url({svg_path})"
            )

        # Apply branding palette & typography if available
        palette = load_branding_palette(project_root)
        typography = load_branding_typography(project_root)
        stylesheet = apply_branding_to_stylesheet(stylesheet, palette, typography)

        logger.info("Theme loaded successfully")
        return stylesheet
    except Exception as e:
        logger.error(f"Error loading theme: {e}")
        return ""


def _resource_base(project_root: str | None) -> str:
    """Return base resource path (supports PyInstaller onefile via sys._MEIPASS)."""
    # Prefer PyInstaller temp folder when present
    base = getattr(sys, "_MEIPASS", None)
    if base and os.path.isdir(base):
        return base
    # Fallback to project root
    if project_root is None:
        current_file = os.path.abspath(__file__)
        project_root = os.path.dirname(os.path.dirname(current_file))
    return project_root


def find_branding_root(project_root: str | None = None) -> str | None:
    """
    Locate the Redline Arbitrage Branding Suite root.

    Checks common locations:
    - Dev path: <project_root>/Redline_Arbitrage_Branding_Suite/Redline_Arbitrage_Branding
    - Packaged path: <base>/resources/branding
    """
    base = _resource_base(project_root)
    # Packaged path (PyInstaller add-data target)
    packaged = os.path.join(base, "resources", "branding")
    if os.path.isdir(packaged):
        return packaged
    # Dev path
    if project_root is None:
        current_file = os.path.abspath(__file__)
        project_root = os.path.dirname(os.path.dirname(current_file))
    dev = os.path.join(
        project_root, "Redline_Arbitrage_Branding_Suite", "Redline_Arbitrage_Branding"
    )
    if os.path.isdir(dev):
        return dev
    return None


def find_social_root(project_root: str | None = None) -> str | None:
    """
    Locate the Redline Arbitrage Social Kit root.

    Checks common locations:
    - Packaged path: <base>/resources/social_kit
    - Dev path: <project_root>/Redline_Arbitrage_Social_Kit
    """
    base = _resource_base(project_root)
    packaged = os.path.join(base, "resources", "social_kit")
    if os.path.isdir(packaged):
        return packaged
    if project_root is None:
        current_file = os.path.abspath(__file__)
        project_root = os.path.dirname(os.path.dirname(current_file))
    dev = os.path.join(project_root, "Redline_Arbitrage_Social_Kit")
    if os.path.isdir(dev):
        return dev
    return None


def load_branding_palette(project_root: str | None = None) -> dict:
    """Load branding palette JSON as dict, empty dict if unavailable."""
    root = find_branding_root(project_root)
    if not root:
        return {}
    palette_path = os.path.join(root, "palette.json")
    try:
        with open(palette_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def load_branding_typography(project_root: str | None = None) -> dict:
    """Load branding typography JSON as dict, empty dict if unavailable."""
    root = find_branding_root(project_root)
    if not root:
        return {}
    typo_path = os.path.join(root, "typography.json")
    try:
        with open(typo_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _qss_safe_font_list(fonts: str | list[str]) -> str:
    """
    Convert typography fonts into a QSS-safe font-family list.

    Quotes non-generic family names and keeps generic families unquoted.
    """
    if isinstance(fonts, str):
        raw = [x.strip() for x in fonts.split(",") if x.strip()]
    else:
        raw = list(fonts)
    generic = {"serif", "sans-serif", "monospace", "system-ui"}
    parts = []
    for name in raw:
        if name.lower() in generic:
            parts.append(name)
        else:
            parts.append(f'"{name}"')
    return ", ".join(parts)


def apply_branding_to_stylesheet(stylesheet: str, palette: dict, typography: dict) -> str:
    """
    Apply palette and typography to the loaded QSS.

    - Replaces foundational colors using palette.json when provided
    - Updates font-family declarations using typography.json
    """
    if not stylesheet:
        return stylesheet

    # Colors mapping (only if keys exist)
    mapping = {}
    if palette:
        if palette.get("primary_red"):
            mapping["#FF0033"] = palette["primary_red"]
        if palette.get("dark_red"):
            mapping["#D00000"] = palette["dark_red"]
        if palette.get("carbon_black"):
            mapping["#0D0D0F"] = palette["carbon_black"]
        if palette.get("text_white"):
            # Replace off-white with branding white
            mapping["#E6E6E6"] = palette["text_white"]
        if palette.get("muted_gray"):
            mapping["#9AA0A6"] = palette["muted_gray"]

    for src, dst in mapping.items():
        stylesheet = stylesheet.replace(src, dst)

    # Fonts
    fonts_value = typography.get("fonts") if typography else None
    if fonts_value:
        font_list = _qss_safe_font_list(fonts_value)
        # Common font-family patterns to replace
        patterns = [
            'font-family: "Rajdhani", "Orbitron", "Segoe UI", "Arial", sans-serif;',
            'font-family: "Rajdhani", "Orbitron", sans-serif;',
            'font-family: "Rajdhani", sans-serif;',
            'font-family: "Orbitron", "Rajdhani", monospace;',
        ]
        for pat in patterns:
            if pat in stylesheet:
                stylesheet = stylesheet.replace(pat, f"font-family: {font_list};")

    return stylesheet


def load_app_icon(project_root: str | None = None) -> QIcon | None:
    """Build and return the application QIcon from the branding icon set."""
    root = find_branding_root(project_root)
    if not root:
        return None
    icons_dir = os.path.join(root, "icons")
    ico_path = os.path.join(icons_dir, "Redline_Arbitrage.ico")
    svg_path = os.path.join(icons_dir, "Redline_Arbitrage.svg")
    icon = QIcon()
    if os.path.isfile(ico_path):
        # .ico often contains multiple sizes and is best for Windows taskbar
        icon = QIcon(ico_path)
        return icon
    # Fallback to SVG
    if os.path.isfile(svg_path):
        icon = QIcon(svg_path)
        return icon
    return None


def apply_accent_button(button: QPushButton):
    """
    Apply accent styling to a button (red glow on hover).

    Args:
        button: QPushButton to style
    """
    if button:
        button.setProperty("accent", True)
        button.style().unpolish(button)
        button.style().polish(button)


class _HoverShadowEffect(QObject):
    """Event filter to add/remove a drop shadow effect on hover."""

    def __init__(self, target: QPushButton, color: QColor, blur_radius: int = 15):
        super().__init__(target)
        self._target = target
        self._color = color
        self._blur = blur_radius

    def eventFilter(self, obj, event):
        if obj is self._target:
            if event.type() == QEvent.Type.Enter:
                effect = QGraphicsDropShadowEffect(self._target)
                effect.setBlurRadius(self._blur)
                effect.setColor(self._color)
                effect.setOffset(0, 0)
                self._target.setGraphicsEffect(effect)
            elif event.type() == QEvent.Type.Leave:
                # Remove effect on hover leave
                self._target.setGraphicsEffect(None)
        return False


def attach_accent_hover_effect(button: QPushButton, color_hex: str = "#FF0033", alpha: float = 0.8, blur_radius: int = 15):
    """Attach a glow-like hover effect to an accent button using QGraphicsDropShadowEffect.

    Args:
        button: The QPushButton to enhance.
        color_hex: Hex color string for glow.
        alpha: Alpha in range [0,1] for glow opacity.
        blur_radius: Blur radius for the shadow.
    """
    if not button:
        return
    # Avoid attaching duplicate handlers
    if hasattr(button, "_hover_shadow_handler") and getattr(button, "_hover_shadow_handler"):
        return
    color = QColor(color_hex)
    color.setAlphaF(max(0.0, min(1.0, alpha)))
    handler = _HoverShadowEffect(button, color, blur_radius)
    button.installEventFilter(handler)
    # Keep a reference to prevent GC
    if not hasattr(button, "_hover_shadow_handler"):
        button._hover_shadow_handler = handler


def polish_widget(widget):
    """
    Helper to polish a widget to apply property-based styles.

    Args:
        widget: Widget to polish
    """
    if widget:
        widget.style().unpolish(widget)
        widget.style().polish(widget)


def apply_label_glow(widget, color_hex: str = "#FF0033", alpha: float = 0.8, blur_radius: int = 12):
    """Apply a static glow to a label-like widget using QGraphicsDropShadowEffect.

    Note: Qt stylesheets do not support text-shadow; this function provides a visual
    alternative without stylesheet warnings.
    """
    if widget is None:
        return
    color = QColor(color_hex)
    color.setAlphaF(max(0.0, min(1.0, alpha)))
    effect = QGraphicsDropShadowEffect(widget)
    effect.setBlurRadius(blur_radius)
    effect.setColor(color)
    effect.setOffset(0, 0)
    widget.setGraphicsEffect(effect)


def _hex_to_rgb(hex_color: str) -> tuple[int, int, int] | None:
    """Convert #RRGGBB or RRGGBB to (r,g,b)."""
    if not hex_color:
        return None
    s = hex_color.strip()
    if s.startswith("#"):
        s = s[1:]
    if len(s) != 6:
        return None
    try:
        r = int(s[0:2], 16)
        g = int(s[2:4], 16)
        b = int(s[4:6], 16)
        return (r, g, b)
    except Exception:
        return None


def _relative_luminance(r: int, g: int, b: int) -> float:
    """Compute relative luminance from sRGB components (0..255)."""
    def srgb_to_linear(c: float) -> float:
        c = c / 255.0
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4

    R = srgb_to_linear(r)
    G = srgb_to_linear(g)
    B = srgb_to_linear(b)
    return 0.2126 * R + 0.7152 * G + 0.0722 * B


def _is_dark_ui(project_root: str | None = None) -> bool:
    """
    Heuristic to detect dark UI theme.

    Uses branding palette carbon_black if available; otherwise assumes default theme color #0D0D0F.
    """
    try:
        palette = load_branding_palette(project_root)
        base_hex = palette.get("carbon_black") if palette else "#0D0D0F"
        rgb = _hex_to_rgb(base_hex)
        if not rgb:
            rgb = _hex_to_rgb("#0D0D0F")
        lum = _relative_luminance(*rgb) if rgb else 0.0
        # Threshold: <= 0.2 treated as dark
        return lum <= 0.2
    except Exception:
        return True


def _best_logo_png(project_root: str | None = None) -> str | None:
    """
    Choose the best available PNG logo path considering both Branding Suite and Social Kit.

    Preference order (first available, highest resolution wins):
    1) Branding: logos/horizontal.png
    2) Social Kit: avatars/RL_full.png
    3) Social Kit: avatars/RL_white.png
    4) Social Kit: avatars/RL_flat.png
    """
    branding_root = find_branding_root(project_root)
    social_root = find_social_root(project_root)

    prefer_white = _is_dark_ui(project_root)

    # Construct candidates with preference ordering
    candidates: list[str] = []
    if prefer_white and social_root:
        # Prefer white avatar first when dark UI
        candidates.append(os.path.join(social_root, "avatars", "RL_white.png"))

    if branding_root:
        candidates.append(os.path.join(branding_root, "logos", "horizontal.png"))

    if social_root:
        # Remaining Social Kit options
        candidates.extend(
            [
                os.path.join(social_root, "avatars", "RL_full.png"),
                os.path.join(social_root, "avatars", "RL_flat.png"),
            ]
        )

    # Filter to existing files
    existing = [p for p in candidates if p and os.path.isfile(p)]
    if not existing:
        return None

    # If the first preferred candidate exists, return it immediately
    if existing:
        first_choice = existing[0]
        # When prefer_white is true, RL_white.png (if present) is first_choice and wins immediately
        # Otherwise, choose the largest area for crispness among the remaining candidates
        if not (prefer_white and os.path.basename(first_choice).lower() == "rl_white.png"):
            best_path = first_choice
            best_area = -1
            for p in existing:
                try:
                    img = QImage(p)
                    area = img.width() * img.height()
                    if area > best_area:
                        best_area = area
                        best_path = p
                except Exception:
                    if best_area < 0:
                        best_path = p
                        best_area = 0
                    continue
            return best_path
        else:
            return first_choice

    return None


def branding_paths(project_root: str | None = None) -> dict:
    """Return key branding and social asset paths if available."""
    branding_root = find_branding_root(project_root)
    social_root = find_social_root(project_root)

    if not branding_root and not social_root:
        return {}

    # Compute primary logo candidates
    logo_png = _best_logo_png(project_root)
    logo_svg = None
    if branding_root:
        svg_candidate = os.path.join(branding_root, "logos", "horizontal.svg")
        logo_svg = svg_candidate if os.path.isfile(svg_candidate) else None

    paths = {
        "root": branding_root or social_root,
        "icons": os.path.join(branding_root, "icons") if branding_root else None,
        "logos": os.path.join(branding_root, "logos") if branding_root else None,
        "ico": os.path.join(branding_root, "icons", "Redline_Arbitrage.ico")
        if branding_root
        else None,
        "svg": os.path.join(branding_root, "icons", "Redline_Arbitrage.svg")
        if branding_root
        else None,
        "logo_horizontal_png": logo_png,
        "logo_horizontal_svg": logo_svg,
        # Social Kit extras
        "social_root": social_root,
        "avatar_full_png": os.path.join(social_root, "avatars", "RL_full.png")
        if social_root
        else None,
        "avatar_white_png": os.path.join(social_root, "avatars", "RL_white.png")
        if social_root
        else None,
        "avatar_flat_png": os.path.join(social_root, "avatars", "RL_flat.png")
        if social_root
        else None,
    }

    # Remove keys with None values for cleanliness
    return {k: v for k, v in paths.items() if v}
