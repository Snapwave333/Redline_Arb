"""
Main entry point for the Arbitrage Betting Bot.

Updated: Remove onboarding splash/welcome flow and open directly to the dashboard.
"""

import os
import sys
try:
    # Import Qt resources early so QSS :/ paths resolve if compiled
    from resources import resources_rc  # noqa: F401
except Exception:
    pass

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QIcon

from gui.main_window import ArbitrageBotGUI
from gui.theme_utils import load_app_icon, load_theme_stylesheet
from config.settings import Config


def main_window_factory():
    """Factory function to create main window instance."""
    return ArbitrageBotGUI()


if __name__ == "__main__":
    # Enable high DPI scaling
    # Robust DPI settings across PyQt5/PyQt6
    for _attr in ("AA_EnableHighDpiScaling", "AA_UseHighDpiPixmaps"):
        try:
            QApplication.setAttribute(getattr(Qt.ApplicationAttribute, _attr), True)
        except Exception:
            try:
                QApplication.setAttribute(getattr(Qt, _attr), True)
            except Exception:
                pass

    # Detect production mode and suppress onboarding
    is_production = (
        os.getenv("ARBYS_PRODUCTION", "0") == "1"
        or os.getenv("ARBYS_SUPPRESS_WIZARD", "0") == "1"
        or os.getenv("ARBYS_SKIP_ONBOARDING", "0") == "1"
        or getattr(sys, "frozen", False)
    )
    if is_production:
        # Propagate suppression to downstream components
        os.environ["ARBYS_SUPPRESS_WIZARD"] = "1"

    app = QApplication(sys.argv)
    # Set taskbar/app icon from branding suite if available
    try:
        icon = load_app_icon()
        if isinstance(icon, QIcon):
            app.setWindowIcon(icon)
    except Exception:
        pass

    # Apply theme directly (no onboarding bootstrap)
    try:
        app.setStyle("Fusion")
        project_root = os.path.dirname(os.path.abspath(__file__))
        stylesheet = load_theme_stylesheet(project_root)
        # Optionally append carbon fiber background QSS for top-level widget
        if Config.get_carbon_bg_enabled():
            try:
                qss_path = os.path.join(project_root, "resources", "desktop_qt_usage.qss")
                if os.path.exists(qss_path):
                    with open(qss_path, encoding="utf-8") as f:
                        carbon_qss = f.read()
                    tile = Config.get_carbon_tile()
                    # Swap PNG URL to requested tile size (256/512/1024)
                    for size in (256, 512, 1024):
                        carbon_qss = carbon_qss.replace(
                            f"carbon_twill_{size}.png",
                            f"carbon_twill_{tile}.png"
                        )
                    # Fallback to absolute path when Qt resources are not compiled
                    abs_png = os.path.join(project_root, "resources", "themes", "carbon", f"carbon_twill_{tile}.png")
                    abs_png = abs_png.replace("\\", "/")
                    carbon_qss = carbon_qss.replace(
                        f":/themes/carbon/carbon_twill_{tile}.png",
                        abs_png
                    )
                    stylesheet = (stylesheet or "") + "\n" + carbon_qss
            except Exception:
                pass
        if stylesheet:
            app.setStyleSheet(stylesheet)
    except Exception:
        # If theme fails, continue with defaults
        pass

    # Create and show the main window directly (no splash/welcome)
    main_window = main_window_factory()
    try:
        main_window.show()
        # Ensure the window gains focus on Windows
        try:
            main_window.raise_()
            main_window.activateWindow()
        except Exception:
            pass
    except Exception:
        # Fallback to delayed show if immediate show fails
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(100, main_window.show)
        QTimer.singleShot(200, lambda: (
            getattr(main_window, "raise_", lambda: None)(),
            getattr(main_window, "activateWindow", lambda: None)()
        ))

    sys.exit(app.exec())
